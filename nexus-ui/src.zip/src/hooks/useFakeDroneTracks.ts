"use client";

/**
 * 假无人机航迹数据 Hook
 * 用于前端测试时加载三个假的无人机目标
 */

import { useEffect } from "react";
import { useTrackStore } from "@/stores/track-store";
import { useAlertStore } from "@/stores/alert-store";
import type { Track } from "@/lib/map-entity-model";
import { startFakeNetworkStats, stopFakeNetworkStats } from "@/lib/fake-data-generator";

/** 三个假无人机航迹数据 */
const FAKE_DRONE_TRACKS: Track[] = [
  {
    id: "drone-fake-1",
    showID: "drone-fake-1",
    uniqueID: "drone-fake-1",
    trackId: "drone-001",
    name: "无人机1号",
    type: "air",
    disposition: "friendly",
    lat: 37.545,
    lng: 122.095,
    altitude: 500,
    heading: 45,
    speed: 120,
    sensor: "雷达",
    lastUpdate: new Date().toISOString(),
    starred: false,
    isAirTrack: true,
    targetType: "无人机",
    course: 45,
    isVirtual: false,
    isUav: true,
    historyTrail: [
      [122.095, 37.545],
      [122.094, 37.544],
      [122.093, 37.543],
      [122.092, 37.542]
    ]
  },
  {
    id: "drone-fake-2",
    showID: "drone-fake-2",
    uniqueID: "drone-fake-2",
    trackId: "drone-002",
    name: "无人机2号",
    type: "air",
    disposition: "neutral",
    lat: 37.550,
    lng: 122.100,
    altitude: 800,
    heading: 270,
    speed: 90,
    sensor: "雷达",
    lastUpdate: new Date().toISOString(),
    starred: false,
    isAirTrack: true,
    targetType: "无人机",
    course: 270,
    isVirtual: false,
    isUav: true,
    historyTrail: [
      [122.100, 37.550],
      [122.099, 37.551],
      [122.098, 37.552],
      [122.097, 37.553]
    ]
  },
  {
    id: "drone-fake-3",
    showID: "drone-fake-3",
    uniqueID: "drone-fake-3",
    trackId: "drone-003",
    name: "无人机3号",
    type: "air",
    disposition: "hostile",
    lat: 37.540,
    lng: 122.090,
    altitude: 600,
    heading: 180,
    speed: 150,
    sensor: "雷达",
    lastUpdate: new Date().toISOString(),
    starred: false,
    isAirTrack: true,
    targetType: "无人机",
    course: 180,
    isVirtual: false,
    isUav: true,
    historyTrail: [
      [122.090, 37.540],
      [122.089, 37.539],
      [122.088, 37.538],
      [122.087, 37.537]
    ]
  }
];

/**
 * 加载假无人机航迹数据的 Hook
 * 在开发/测试环境下自动加载三个无人机目标到航迹库
 *
 * 重要：为了让假航迹显示在地图上，我们还需要创建对应的假告警，
 * 因为 track-store 只渲染匹配告警的航迹。
 *
 * 持续更新：为了避免假数据被超时清理机制清理（告警25秒超时，航迹10-60秒超时），
 * 我们会定期更新假数据的时间戳，让它们保持"新鲜"。
 */
export function useFakeDroneTracks() {
  useEffect(() => {
    // 检查是否为开发环境或启用了假数据模式
    const isDev = process.env.NODE_ENV === "development";
    const useFakeData = localStorage.getItem("USE_FAKE_DATA") === "true";

    if (!isDev && !useFakeData) {
      return;
    }

    console.log("🎭 开始加载假无人机数据...");

    // 启动网络统计假数据
    startFakeNetworkStats();

    let refreshTimer: ReturnType<typeof setInterval> | null = null;

    // 延迟加载，确保 store 已经初始化
    const initialTimer = setTimeout(() => {
      // 定期刷新假数据的时间戳，避免被超时清理
      const refreshFakeData = () => {
        const now = new Date().toISOString();
        const trackStore = useTrackStore.getState();
        const alertStore = useAlertStore.getState();

        // 1. 更新假航迹的时间戳
        const updatedTracks = FAKE_DRONE_TRACKS.map((track) => ({
          ...track,
          lastUpdate: now,
        }));
        trackStore.setTracks(updatedTracks);

        // 2. 更新假告警的时间戳
        const updatedAlarms = FAKE_DRONE_TRACKS.map((track) => ({
          id: `alarm-${track.id}`,
          trackId: track.trackId || track.id,
          showID: track.showID,
          type: "air" as const,
          level: "medium" as const,
          disposition: track.disposition,
          createdAt: now,
          lastUpdateTime: now,
          verified: false,
          latitude: track.lat,
          longitude: track.lng,
          altitude: track.altitude,
          heading: track.heading,
          speed: track.speed,
          targetName: track.name,
          targetType: track.targetType || "无人机",
          source: "fake-data",
        }));

        updatedAlarms.forEach((alarm) => {
          alertStore.upsertAlarm(alarm);
        });

        console.log("🔄 假数据时间戳已更新:", now);
      };

      // 初始加载
      refreshFakeData();
      console.log("✅ 假无人机数据已初始加载，数量:", FAKE_DRONE_TRACKS.length);

      // 每10秒刷新一次时间戳（告警超时是25秒，航迹超时是10-60秒）
      refreshTimer = setInterval(refreshFakeData, 10_000);
      console.log("🔄 假数据自动刷新已启用（每10秒）");

    }, 2000); // 初始延迟2秒

    return () => {
      clearTimeout(initialTimer);
      if (refreshTimer) clearInterval(refreshTimer);
      stopFakeNetworkStats(); // 停止网络统计假数据
    };
  }, []);
}