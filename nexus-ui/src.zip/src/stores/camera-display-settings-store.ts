"use client";

import { create } from 'zustand';

/**
 * 光电显示设置 Store
 *
 * 存储每个光电（相机）的显示配置，这些配置会实时应用到地图上的光电 FOV 显示
 */

export interface CameraDisplaySettings {
  /** 显示视场角扇区 */
  showFovSector: boolean;
  /** 显示中心标签 */
  showCenterLabel: boolean;
  /** FOV填充颜色 */
  fovFillColor: string;
  /** FOV填充透明度 */
  fovFillOpacity: number;
}

export const DEFAULT_CAMERA_SETTINGS: CameraDisplaySettings = {
  showFovSector: true,
  showCenterLabel: true,
  fovFillColor: "#6ee7b7",
  fovFillOpacity: 0.2,
};

export interface CameraDisplaySettingsStore {
  /** 每个光电ID对应的设置 */
  settings: Record<string, CameraDisplaySettings>;

  /** 获取特定光电的设置 */
  getCameraSettings: (cameraId: string) => CameraDisplaySettings;

  /** 设置特定光电的配置 */
  setCameraSettings: (cameraId: string, settings: Partial<CameraDisplaySettings>) => void;

  /** 重置特定光电为默认设置 */
  resetCameraSettings: (cameraId: string) => void;
}

export const useCameraDisplaySettingsStore = create<CameraDisplaySettingsStore>()((set, get) => {
  // 初始化时自动从 localStorage 加载设置（仅客户端）
  let initialSettings: Record<string, CameraDisplaySettings> = {};
  if (typeof window !== 'undefined') {
    try {
      const saved = localStorage.getItem('camera-display-settings');
      if (saved) {
        initialSettings = JSON.parse(saved);
      }
    } catch (e) {
      console.error('Failed to load camera settings from localStorage:', e);
    }
  }

  return {
    settings: initialSettings,

    getCameraSettings: (cameraId: string) => {
      const cameraSettings = get().settings[cameraId];
      return { ...DEFAULT_CAMERA_SETTINGS, ...cameraSettings };
    },

    setCameraSettings: (cameraId: string, newSettings: Partial<CameraDisplaySettings>) => {
      set((state) => ({
        settings: {
          ...state.settings,
          [cameraId]: {
            ...state.settings[cameraId],
            ...newSettings,
          },
        },
      }));

      // 尝试保存到 localStorage（客户端）
      if (typeof window !== 'undefined') {
        try {
          localStorage.setItem('camera-display-settings', JSON.stringify(get().settings));
        } catch (e) {
          // 忽略 localStorage 错误
        }
      }
    },

    resetCameraSettings: (cameraId: string) => {
      set((state) => ({
        settings: {
          ...state.settings,
          [cameraId]: DEFAULT_CAMERA_SETTINGS,
        },
      }));

      // 尝试保存到 localStorage（客户端）
      if (typeof window !== 'undefined') {
        try {
          localStorage.setItem('camera-display-settings', JSON.stringify(get().settings));
        } catch (e) {
          // 忽略 localStorage 错误
        }
      }
    },
  };
});
