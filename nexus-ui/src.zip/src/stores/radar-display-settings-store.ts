"use client";

import { create } from 'zustand';

/**
 * 雷达显示设置 Store
 *
 * 存储每个雷达的显示配置，这些配置会实时应用到地图上的雷达显示
 */

export interface RadarDisplaySettings {
  /** 显示覆盖范围（填充） */
  showCoverage: boolean;
  /** 显示距离环 */
  showRangeRings: boolean;
  /** 显示中心标签 */
  showCenterLabel: boolean;
  /** 距离环间隔（米） */
  rangeRingInterval: number;
  /** 距离环颜色 */
  rangeRingColor: string;
  /** 覆盖填充颜色 */
  coverageFillColor: string;
  /** 覆盖填充透明度 */
  coverageFillOpacity: number;
}

export const DEFAULT_SETTINGS: RadarDisplaySettings = {
  showCoverage: true,
  showRangeRings: true,
  showCenterLabel: true,
  rangeRingInterval: 3000,
  rangeRingColor: "#6ee7b7",
  coverageFillColor: "#6ee7b7",
  coverageFillOpacity: 0.15,
};

export interface RadarDisplaySettingsStore {
  /** 每个雷达ID对应的设置 */
  settings: Record<string, RadarDisplaySettings>;

  /** 获取特定雷达的设置 */
  getRadarSettings: (radarId: string) => RadarDisplaySettings;

  /** 设置特定雷达的配置 */
  setRadarSettings: (radarId: string, settings: Partial<RadarDisplaySettings>) => void;

  /** 批量设置多个雷达的配置 */
  setMultipleRadarSettings: (radarIds: string[], settings: Partial<RadarDisplaySettings>) => void;

  /** 重置特定雷达为默认设置 */
  resetRadarSettings: (radarId: string) => void;

  /** 从 localStorage 加载设置（客户端安全） */
  loadFromLocalStorage: () => void;
}

export const useRadarDisplaySettingsStore = create<RadarDisplaySettingsStore>()((set, get) => {
  // 初始化时自动从 localStorage 加载设置（仅客户端）
  let initialSettings: Record<string, RadarDisplaySettings> = {};
  if (typeof window !== 'undefined') {
    try {
      const saved = localStorage.getItem('radar-display-settings');
      if (saved) {
        initialSettings = JSON.parse(saved);
      }
    } catch (e) {
      console.error('Failed to load radar settings from localStorage:', e);
    }
  }

  return {
    settings: initialSettings,

    getRadarSettings: (radarId: string) => {
      const radarSettings = get().settings[radarId];
      return { ...DEFAULT_SETTINGS, ...radarSettings };
    },

    setRadarSettings: (radarId: string, newSettings: Partial<RadarDisplaySettings>) => {
      set((state) => ({
        settings: {
          ...state.settings,
          [radarId]: {
            ...state.settings[radarId],
            ...newSettings,
          },
        },
      }));

      // 尝试保存到 localStorage（客户端）
      if (typeof window !== 'undefined') {
        try {
          localStorage.setItem('radar-display-settings', JSON.stringify(get().settings));
        } catch (e) {
          // 忽略 localStorage 错误
        }
      }
    },

    setMultipleRadarSettings: (radarIds: string[], newSettings: Partial<RadarDisplaySettings>) => {
      set((state) => {
        const updatedSettings = { ...state.settings };
        radarIds.forEach((radarId) => {
          updatedSettings[radarId] = {
            ...updatedSettings[radarId],
            ...newSettings,
          };
        });
        return { settings: updatedSettings };
      });
    },

    resetRadarSettings: (radarId: string) => {
      set((state) => ({
        settings: {
          ...state.settings,
          [radarId]: DEFAULT_SETTINGS,
        },
      }));

      // 尝试保存到 localStorage（客户端）
      if (typeof window !== 'undefined') {
        try {
          localStorage.setItem('radar-display-settings', JSON.stringify(get().settings));
        } catch (e) {
          // 忽略 localStorage 错误
        }
      }
    },

    loadFromLocalStorage: () => {
      if (typeof window === 'undefined') return;
      try {
        const saved = localStorage.getItem('radar-display-settings');
        if (saved) {
          const parsed = JSON.parse(saved);
          set({ settings: parsed });
        }
      } catch (e) {
        console.error('Failed to load radar settings from localStorage:', e);
      }
    },
  };
});
