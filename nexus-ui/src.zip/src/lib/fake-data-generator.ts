/**
 * Fake Data Generator
 *
 * 为前端显示效果测试生成假数据：
 * - 相机数据：让相机1的视场角能显示
 * - 无人机航迹数据：让3个无人机显示在目标列表和地图上
 * - 网络统计数据：模拟各种数据源的接收统计
 */

import { useTrackStore } from "@/stores/track-store";
import { useAssetStore } from "@/stores/asset-store";
import type { Track } from "@/lib/map-entity-model";
import type { AssetData } from "@/stores/asset-store";
import {
  recordTrackReceived,
  recordDroneReceived,
  recordEntityReceived,
  recordAlertReceived,
  recordZoneReceived,
  recordCameraReceived,
  recordDockReceived,
  recordDroneFlightPathReceived,
} from "@/stores/network-stats-store";

/**
 * 生成假相机数据
 * 相机1的视场角数据，用于测试FOV显示功能
 */
export function generateFakeCameraData(): AssetData {
  const now = new Date().toISOString();

  return {
    id: "camera-fake-1",
    name: "相机fake",
    asset_type: "camera",
    status: "online",
    disposition: "friendly",
    lat: 37.545,
    lng: 122.095,
    range_km: 5,
    heading: 135,
    fov_angle: 90,
    properties: {
      center_icon_visible: true,
      center_name_visible: true,
      fov_sector_visible: true,
      map_friendly_color: "#6ee7b7",
      config_kind: "camera"
    },
    mission_status: "monitoring",
    assigned_target_id: null,
    target_lat: null,
    target_lng: null,
    created_at: now,
    updated_at: now
  };
}

/**
 * 生成假无人机航迹数据
 * 三个不同态势的无人机用于测试目标列表和地图显示
 */
export function generateFakeDroneTracks(): Track[] {
  const now = new Date().toISOString();

  return [
    {
      id: "drone-fake-1",
      showID: "drone-fake-1",
      uniqueID: "drone-fake-1",
      trackId: "drone-001",
      name: "无人机1号",
      type: "air",
      disposition: "friendly",
      lat: 37.545,
      lng: 122.095,
      altitude: 500,
      heading: 45,
      speed: 120,
      sensor: "雷达",
      lastUpdate: now,
      starred: false,
      isAirTrack: true,
      targetType: "无人机",
      course: 45,
      isVirtual: false,
      isUav: true,
      historyTrail: [
        [122.095, 37.545],
        [122.094, 37.544],
        [122.093, 37.543],
        [122.092, 37.542]
      ]
    },
    {
      id: "drone-fake-2",
      showID: "drone-fake-2",
      uniqueID: "drone-fake-2",
      trackId: "drone-002",
      name: "无人机2号",
      type: "air",
      disposition: "neutral",
      lat: 37.550,
      lng: 122.100,
      altitude: 800,
      heading: 270,
      speed: 90,
      sensor: "雷达",
      lastUpdate: now,
      starred: false,
      isAirTrack: true,
      targetType: "无人机",
      course: 270,
      isVirtual: false,
      isUav: true,
      historyTrail: [
        [122.100, 37.550],
        [122.099, 37.551],
        [122.098, 37.552],
        [122.097, 37.553]
      ]
    },
    {
      id: "drone-fake-3",
      showID: "drone-fake-3",
      uniqueID: "drone-fake-3",
      trackId: "drone-003",
      name: "无人机3号",
      type: "air",
      disposition: "hostile",
      lat: 37.540,
      lng: 122.090,
      altitude: 600,
      heading: 180,
      speed: 150,
      sensor: "雷达",
      lastUpdate: now,
      starred: false,
      isAirTrack: true,
      targetType: "无人机",
      course: 180,
      isVirtual: false,
      isUav: true,
      historyTrail: [
        [122.090, 37.540],
        [122.089, 37.539],
        [122.088, 37.538],
        [122.087, 37.537]
      ]
    }
  ];
}

/**
 * 加载假数据到系统中
 * 在前端初始化时调用此函数
 */
export function loadFakeData() {
  const trackStore = useTrackStore.getState();
  const assetStore = useAssetStore.getState();

  // 添加假相机数据
  const fakeCamera = generateFakeCameraData();
  assetStore.upsertAsset(fakeCamera);

  // 添加假无人机航迹数据
  const fakeDroneTracks = generateFakeDroneTracks();
  trackStore.setTracks(fakeDroneTracks);

  console.log("🎭 Fake data loaded:", {
    camera: fakeCamera.name,
    drones: fakeDroneTracks.length
  });
}

/**
 * 模拟网络统计数据更新
 * 定期调用各种 recordXxx 函数来生成假的网络统计数据
 * 让"网络数据接收统计"弹窗能显示数据
 */
let networkStatsInterval: ReturnType<typeof setInterval> | null = null;

export function startFakeNetworkStats() {
  if (networkStatsInterval) return; // 避免重复启动

  // 立即记录一次初始数据
  recordInitialFakeStats();

  // 每 2 秒更新一次统计数据，模拟实时数据流
  networkStatsInterval = setInterval(() => {
    recordFakeNetworkStatsUpdate();
  }, 2000);

  console.log("🎭 Fake network stats started");
}

/**
 * 停止模拟网络统计数据
 */
export function stopFakeNetworkStats() {
  if (networkStatsInterval) {
    clearInterval(networkStatsInterval);
    networkStatsInterval = null;
    console.log("🎭 Fake network stats stopped");
  }
}

/**
 * 记录初始统计数据，让各分类都有数据
 */
function recordInitialFakeStats() {
  // 航迹数据（对空/对海）
  for (let i = 0; i < 50; i++) {
    recordTrackReceived(true);  // 对空航迹
    recordTrackReceived(false); // 对海航迹
  }

  // 无人机数据
  for (let i = 0; i < 30; i++) {
    recordDroneReceived();
  }

  // 实体数据（各种类型）
  for (let i = 0; i < 20; i++) {
    recordEntityReceived("entity-001", "radar");
    recordEntityReceived("entity-002", "camera");
    recordEntityReceived("entity-003", "laser");
    recordEntityReceived("entity-004", "tdoa");
  }

  // 告警数据
  for (let i = 0; i < 15; i++) {
    recordAlertReceived();
  }

  // 区域数据
  for (let i = 0; i < 10; i++) {
    recordZoneReceived();
  }

  // 光电数据（多个相机）
  recordCameraReceived("camera-fake-1");
  recordCameraReceived("camera-fake-2");
  for (let i = 0; i < 25; i++) {
    recordCameraReceived("camera-fake-1");
  }
  for (let i = 0; i < 18; i++) {
    recordCameraReceived("camera-fake-2");
  }

  // 机场数据
  for (let i = 0; i < 12; i++) {
    recordDockReceived();
  }

  // 航线数据
  for (let i = 0; i < 8; i++) {
    recordDroneFlightPathReceived();
  }
}

/**
 * 模拟网络数据更新
 * 每次调用时随机增加一些数据，模拟实时接收
 */
function recordFakeNetworkStatsUpdate() {
  // 随机更新各种数据源
  const updates = [
    () => recordTrackReceived(Math.random() > 0.5), // 对空或对海
    () => recordDroneReceived(),
    () => recordEntityReceived(`entity-${Math.floor(Math.random() * 100)}`, ["radar", "camera", "laser", "tdoa"][Math.floor(Math.random() * 4)]),
    () => recordAlertReceived(),
    () => recordZoneReceived(),
    () => recordCameraReceived(Math.random() > 0.7 ? "camera-fake-1" : "camera-fake-2"),
    () => recordDockReceived(),
    () => recordDroneFlightPathReceived(),
  ];

  // 每次随机执行 5-10 次更新
  const updateCount = 5 + Math.floor(Math.random() * 5);
  for (let i = 0; i < updateCount; i++) {
    const updateFn = updates[Math.floor(Math.random() * updates.length)];
    updateFn();
  }
}