/**
 * 统一弹窗样式系统
 *
 * 【用途】为所有弹窗内容提供统一的样式常量，避免重复编写样式代码
 * 【优势】保证所有弹窗视觉一致性，简化维护，降低出错率
 *
 * 【使用方式】
 * import { MODAL_STYLES } from "@/lib/modal-styles";
 *
 * <div className={MODAL_STYLES.spacing.main}>
 *   <h4 className={MODAL_STYLES.text.sectionTitle}>分组标题</h4>
 *   <div className={MODAL_STYLES.spacing.group}>
 *     <label className={MODAL_STYLES.text.label}>标签文本</label>
 *   </div>
 * </div>
 */

/**
 * 间距系统
 * - main: 主要内容间距（10px）
 * - group: 组内间距（6px）
 */
export const MODAL_SPACING = {
  /** 主要内容间距：space-y-2.5 (10px) - 用于弹窗内容的主要区域 */
  main: "space-y-2.5",
  /** 组内间距：space-y-1.5 (6px) - 用于相关元素分组 */
  group: "space-y-1.5",
} as const;

/**
 * 文本样式
 * - sectionTitle: 分组标题（更粗、更淡）
 * - label: 普通文本（标签、说明）
 * - option: 选项文本（高对比度）
 * - body: 弹窗内普通说明文字（12px）
 *
 * 注意：弹窗内文字最小字号为 text-xs (12px)，小字(10px)仅用于卡片类组件
 */
export const MODAL_TEXT = {
  /**
   * 分组标题 / 区块标题
   * 字号：12px | 字重：bold | 颜色：70% 透明度
   * 用途：显示选项、参数设置等分组标题
   */
  sectionTitle: "text-xs font-bold text-nexus-text-muted/70 pl-1",

  /**
   * 普通文本（标签文字）
   * 字号：12px | 字重：normal | 颜色：次要文字色
   * 用途：表单标签、选项名称
   */
  label: "text-xs font-normal text-nexus-text-secondary pl-1",

  /**
   * 选项文本（普通文本，高对比度）
   * 字号：12px | 字重：normal | 颜色：主要文字色
   * 用途：开关选项的名称文字
   */
  option: "text-xs font-normal text-nexus-text-primary",

  /**
   * 弹窗内普通说明文字
   * 字号：12px | 字重：normal | 颜色：次要文字色
   * 用途：弹窗内容区域的描述文字、说明信息
   */
  body: "text-xs font-normal text-nexus-text-secondary",
} as const;

/**
 * 图标样式
 */
export const MODAL_ICONS = {
  /** 中等图标：14px - 用于选项前的装饰图标 */
  medium: "size-[14px]",
  /** 小图标：12px - 用于下拉菜单项前的图标 */
  small: "size-[12px]",
  /** 图标容器：用于图标+文字的组合，带视觉对齐 */
  withIconContainer: "flex items-center gap-2 pl-1",
} as const;

/**
 * 表单控件样式
 */
export const MODAL_INPUTS = {
  /**
   * 文本输入框 / 下拉选择框
   * 背景：#19191D | 边框：nexus-border | 内边距：12px
   */
  base: "w-full rounded-md border border-nexus-border bg-[#19191D] px-3 py-2 text-xs text-nexus-text-primary focus:border-nexus-border-accent focus:outline-none transition-colors",

  /**
   * 下拉选择框触发按钮
   * 带hover和focus状态
   */
  selectTrigger: "flex w-full items-center justify-between rounded-md border border-nexus-border bg-[#19191D] px-3 py-2 text-left text-xs text-nexus-text-primary hover:border-nexus-border-accent focus:border-nexus-border-accent focus:outline-none transition-colors",

  /**
   * 下拉菜单容器
   */
  dropdownMenu: "absolute z-50 mt-1 max-h-48 w-full overflow-auto rounded-md border border-nexus-border shadow-lg",

  /**
   * 下拉菜单项
   */
  dropdownItem: "flex w-full items-center gap-2 px-3 py-2 text-left text-xs transition-colors hover:bg-nexus-accent/10 text-nexus-text-secondary",

  /**
   * 下拉菜单项（选中状态）
   */
  dropdownItemSelected: "bg-nexus-accent/20 text-nexus-text-primary",
} as const;

/**
 * 按钮样式
 */
export const MODAL_BUTTONS = {
  /**
   * 主要按钮（确认、保存）
   * 背景：accent色 | 文字：白色
   */
  primary: "rounded-md px-3 py-1.5 text-xs font-medium bg-nexus-accent text-white hover:bg-nexus-accent/80 transition-colors",

  /**
   * 次要按钮（取消、关闭）
   * 文字：次要文字色 | hover背景
   */
  secondary: "rounded-md px-3 py-1.5 text-xs font-medium text-nexus-text-secondary hover:bg-nexus-bg-hover hover:text-nexus-text-primary transition-colors",

  /**
   * 辅助按钮（重置、其他）
   * 带图标
   */
  auxiliary: "flex items-center gap-1 rounded-md px-2 py-1 text-xs font-medium text-nexus-text-secondary hover:bg-nexus-bg-hover hover:text-nexus-text-primary transition-colors",

  /**
   * 禁用按钮
   */
  disabled: "bg-nexus-text-muted cursor-not-allowed",

  /**
   * 图标按钮（开关、眼睛等）
   */
  iconButton: "rounded p-1 transition-colors",
} as const;

/**
 * 切换控件样式（开关按钮）
 */
export const MODAL_TOGGLES = {
  /**
   * 切换项容器（label元素）
   * 用于图标+文字+开关按钮的组合
   */
  container: "flex items-center justify-between",

  /**
   * 切换项左侧容器（图标+文字）
   * 带视觉对齐
   */
  leftContainer: "flex items-center gap-2 pl-1",

  /**
   * 图标样式
   */
  icon: "text-nexus-text-muted shrink-0",

  /**
   * 开关按钮（启用状态）
   */
  buttonEnabled: "rounded p-1 transition-colors bg-nexus-accent/20 text-nexus-accent",

  /**
   * 开关按钮（禁用状态）
   */
  buttonDisabled: "rounded p-1 transition-colors bg-nexus-bg-hover text-nexus-text-muted",
} as const;

/**
 * 底部按钮区域样式
 */
export const MODAL_FOOTER = {
  /**
   * 底部容器
   */
  container: "flex items-center justify-between",

  /**
   * 右侧按钮组容器
   */
  rightGroup: "flex gap-1.5",
} as const;

/**
 * 卡片样式（用于数据展示类弹窗，如 NetworkStatsDialog）
 *
 * 注意：卡片组件可以使用小字(10px)，这是唯一允许使用小字的场景
 */
export const MODAL_CARD = {
  /**
   * 卡片容器（基础样式）
   * 尺寸限制：最小宽度180px，最大宽度280px
   */
  container: "rounded-lg px-3 py-4 min-w-[180px] max-w-[280px]", // border border-white/[0.06] 已注释：测试无边框效果

  /**
   * 卡片容器渐变背景样式
   * 使用方式：在容器元素上添加 style={MODAL_CARD.containerStyle}
   * 注意：不包含渐变边框（border-image会移除圆角），只提供渐变背景
   */
  containerStyle: {
    background: "linear-gradient(241deg, #2E2E3A 2%, #2A2A2E 60%)",
  } as const,

  /**
   * 卡片标题容器
   * 标题和计数左对齐，中间有适当间距，与内容区对齐
   * 添加 pl-1.5 (6px) 来匹配数据项的 px-1.5 内边距，确保左右对齐
   */
  header: "mb-2 flex items-center gap-2 pl-1.5", // 添加 pl-1.5 确保与内容区数据项对齐

  /**
   * 卡片标题文字（使用稍大字号以突出分组）
   */
  title: "text-sm font-semibold text-nexus-text-primary",

  /**
   * 卡片计数标签（使用规范的小字样式）
   */
  count: "text-[10px] text-nexus-text-muted",

  /**
   * 卡片内容区域
   */
  content: "space-y-0",

  /**
   * 数据项容器
   * 增加左侧内边距实现视觉对齐：px-1.5 → px-2 (6px → 8px)
   */
  item: "flex items-center gap-2 rounded px-2 py-0.5 hover:bg-[#4B9EFF]/20 transition-colors",

  /**
   * 数据项标签（使用规范的次要文字样式）
   */
  itemLabel: "text-xs text-nexus-text-secondary flex-1 truncate",

  /**
   * 数据项数值（使用规范的小字样式）
   */
  itemValue: "text-[10px] text-nexus-text-muted tabular-nums",

  /**
   * 数据项时间（正常状态）- 使用规范字号
   */
  itemTimeNormal: "text-xs font-mono font-semibold tabular-nums text-emerald-400",

  /**
   * 数据项时间（超时状态）- 使用规范字号
   */
  itemTimeTimeout: "text-xs font-mono font-semibold tabular-nums text-red-400",
} as const;

/**
 * 网格布局样式
 */
export const MODAL_GRID = {
  /**
   * 两列布局
   * 用于 large 尺寸弹窗的表单布局
   */
  twoColumns: "grid grid-cols-2 gap-3",

  /**
   * 响应式卡片布局（自动适配）
   * 使用 CSS Grid 的自动填充功能，根据可用空间动态调整列数
   * 每列最小宽度180px，最大宽度1fr（均分剩余空间）
   */
  autoFit: "grid grid-cols-[repeat(auto-fill,minmax(180px,1fr))] gap-3", // gap-2 → gap-3 增加卡片间距
} as const;

/**
 * 统一导出对象
 * 包含所有弹窗样式常量
 */
export const MODAL_STYLES = {
  spacing: MODAL_SPACING,
  text: MODAL_TEXT,
  icons: MODAL_ICONS,
  inputs: MODAL_INPUTS,
  buttons: MODAL_BUTTONS,
  toggles: MODAL_TOGGLES,
  footer: MODAL_FOOTER,
  card: MODAL_CARD,
  grid: MODAL_GRID,
} as const;
