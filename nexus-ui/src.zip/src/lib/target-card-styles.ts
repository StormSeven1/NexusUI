/**
 * 地图目标属性浮动卡片统一样式系统
 *
 * 【用途】为地图上点击目标/资产后弹出的详情卡片提供统一的样式常量
 * 【优势】保证所有地图目标卡片视觉一致性，简化维护，降低出错率
 *
 * 【使用方式】
 * import { TARGET_CARD } from "@/lib/target-card-styles";
 *
 * <div className={TARGET_CARD.container}>
 *   <div className={TARGET_CARD.header}>...</div>
 *   <div className={TARGET_CARD.content}>...</div>
 * </div>
 */

/**
 * 卡片容器样式
 */
export const TARGET_CARD = {
  /**
   * 卡片容器
   * 尺寸：最小宽度 180px，实际宽度根据内容自适应
   * 圆角：rounded-xl (12px)
   * 背景：background: linear-gradient(241deg, #2E2E3A 0%, #2A2A2E 60%);
   * 边框：无
   * 阴影：0 14px 36px rgba(0,0,0,0.72)
   */
  container: "pointer-events-auto min-w-[180px] w-auto rounded-xl shadow-[0_14px_36px_rgba(0,0,0,0.72)] p-3",

  /**
   * 卡片容器渐变背景样式
   * 使用方式：在容器元素上添加 style={TARGET_CARD.containerStyle}
   */
  containerStyle: {
    background: "linear-gradient(241deg, #2E2E3A 0%, #2A2A2E 60%)",
  } as const,

  /**
   * 卡片头部区域
   * 包含：图标、标题、副标题、标签、关闭按钮
   * 下边距：10px (与内容区间距)
   * 布局：垂直方向，行间距2px
   */
  header: "mb-2.5 flex flex-col gap-0.5",

  /**
   * 头部左侧容器
   * 包含：图标、标题、副标题
   * 布局：图标和标题在一行，副标题在下一行
   */
  headerLeft: "flex min-w-0 items-start gap-2",

  /**
   * 图标容器
   * 尺寸：24x24px
   * 无背景、无边框，直接显示在卡片背景上
   */
  iconContainer: "flex h-6 w-6 shrink-0 items-center justify-center",

  /**
   * 图标内边距容器
   * 直接显示图标，无装饰
   */
  iconWrapper: "h-5 w-5",

  /**
   * 标题容器
   * 包含：标题、标签、副标题
   */
  titleContainer: "min-w-0",

  /**
   * 标题行
   * 包含：标题文字、标签
   */
  titleRow: "flex items-center gap-2",

  /**
   * 标题文字
   * 字号：14px | 字重：semibold | 颜色：主要文字色
   * 截断：truncate
   */
  title: "truncate text-sm font-semibold text-nexus-text-primary",

  /**
   * 副标题文字
   * 字号：10px | 字体：monospace | 颜色：弱化文字色
   */
  subtitle: "font-mono text-[10px] text-nexus-text-muted",

  /**
   * 关闭按钮
   * 内边距：px-2 py-1
   * 圆角：rounded-md
   * 字号：14px
   */
  closeButton: "shrink-0 rounded-md px-2 py-1 text-sm text-nexus-text-secondary hover:bg-white/5 hover:text-nexus-text-primary",

  /**
   * 内容区域
   */
  content: "space-y-0",
} as const;

/**
 * 区块标题样式
 * 用于：概况、运动、处置、关联告警等区块
 */
export const TARGET_CARD_SECTION = {
  /**
   * 区块标题容器
   * 上边距：mt-2
   */
  container: "mt-2 flex items-center justify-between",

  /**
   * 区块标题文字
   * 字号：12px | 字重：semibold | 字间距：wider | 颜色：弱化文字色
   */
  title: "text-xs font-semibold tracking-wider text-nexus-text-muted",

  /**
   * 区块内容容器
   * 上边距：mt-1
   */
  content: "mt-1",
} as const;

/**
 * 数据行样式
 * 用于：标签+数值的数据展示
 */
export const TARGET_CARD_ROW = {
  /**
   * 数据行容器
   * 布局：grid 2列，标签列 60px，数值列 1fr
   * 水平间距：2px
   * 垂直间距：4px
   * 字号：12px
   */
  container: "grid grid-cols-[60px_1fr] gap-x-0.5 gap-y-1 text-xs",

  /**
   * 标签列
   * 颜色：弱化文字色
   */
  label: "text-nexus-text-muted",

  /**
   * 数值列
   * 颜色：主要文字色
   * 最小宽度：0（允许截断）
   */
  value: "min-w-0 text-nexus-text-primary",

  /**
   * 两列数据布局（用于运动参数等）
   */
  twoColumns: "grid grid-cols-2 gap-x-3 gap-y-1.5",

  /**
   * 垂直布局（用于概况等）
   */
  vertical: "flex flex-col gap-y-1.5",
} as const;

/**
 * 徽章样式
 * 用于：敌我标签、类型标签、状态标签等
 */
export const TARGET_CARD_BADGE = {
  /**
   * 基础徽章
   * 内边距：px-2 py-0.5
   * 圆角：rounded-full
   * 字号：10px | 字重：semibold
   * 边框：white/10
   * 背景：white/5
   */
  base: "inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-[10px] font-semibold text-nexus-text-secondary",

  /**
   * 对空航迹标签
   * 颜色：sky
   */
  airTrack: "rounded-full border px-2 py-0.5 text-[10px] font-semibold border-sky-500/30 bg-sky-500/10 text-sky-400",

  /**
   * 对海航迹标签
   * 颜色：emerald
   */
  seaTrack: "rounded-full border px-2 py-0.5 text-[10px] font-semibold border-emerald-500/30 bg-emerald-500/10 text-emerald-400",

  /**
   * 资产类型标签
   */
  assetType: "rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-[10px] font-semibold text-nexus-text-muted",

  /**
   * 告警级别标签
   * 严重：红色
   */
  alarmCritical: "rounded bg-white/5 px-1 text-[9px] text-nexus-text-muted",

  /**
   * 告警类型标签
   */
  alarmType: "rounded bg-white/5 px-1 text-[9px] text-nexus-text-muted",
} as const;

/**
 * 按钮样式
 */
export const TARGET_CARD_BUTTON = {
  /**
   * 主要操作按钮（一键处置）
   * 全宽：w-full
   * 内边距：py-1
   * 圆角：rounded-lg
   * 字号：10px | 字重：semibold
   * 边框：sky-500/30
   * 背景：sky-500/10
   * 颜色：sky-300
   */
  primary: "flex w-full items-center justify-center gap-2 rounded-lg border border-sky-500/30 bg-sky-500/10 py-1 text-[10px] font-semibold text-sky-300 transition hover:bg-sky-500/15 disabled:cursor-not-allowed disabled:opacity-50",

  /**
   * 禁用状态
   */
  disabled: "disabled:cursor-not-allowed disabled:opacity-50",
} as const;

/**
 * 告警卡片样式
 * 用于：关联告警列表中的单个告警项
 */
export const TARGET_CARD_ALERT = {
  /**
   * 告警卡片容器
   * 内边距：px-2.5 py-2
   * 圆角：rounded-lg
   * 边框：white/10
   * 背景：white/5
   */
  container: "rounded-lg border border-white/10 bg-white/5 px-2.5 py-2",

  /**
   * 告警头部
   * 布局：flex，两端对齐
   */
  header: "flex items-center justify-between gap-2",

  /**
   * 告警头部左侧容器
   * 包含：级别、类型、等级
   */
  headerLeft: "flex items-center gap-1.5",

  /**
   * 告警时间
   * 字号：10px | 颜色：弱化文字色
   */
  timestamp: "text-[10px] text-nexus-text-muted",

  /**
   * 告警详情区域
   * 上边距：mt-1
   * 字号：10px | 颜色：弱化文字色
   */
  details: "mt-1 flex flex-wrap gap-x-3 gap-y-0.5 text-[10px] text-nexus-text-muted",

  /**
   * 告警描述
   * 上边距：mt-1
   * 字号：10px | 行高：relaxed | 颜色：弱化文字色
   */
  description: "mt-1 text-[10px] leading-relaxed text-nexus-text-muted",

  /**
   * 严重告警样式
   * 左边框：border-l-2 border-l-red-500/60
   */
  critical: "border-l-2 border-l-red-500/60",

  /**
   * 警告告警样式
   * 左边框：border-l-2 border-l-amber-500/60
   */
  warning: "border-l-2 border-l-amber-500/60",

  /**
   * 信息告警样式
   * 左边框：border-l-2 border-l-zinc-500/40
   */
  info: "border-l-2 border-l-zinc-500/40",

  /**
   * 严重级别文字颜色
   */
  criticalText: "text-red-400",

  /**
   * 警告级别文字颜色
   */
  warningText: "text-amber-400",

  /**
   * 信息级别文字颜色
   */
  infoText: "text-zinc-400",
} as const;

/**
 * 颜色常量
 */
export const TARGET_CARD_COLORS = {
  /**
   * 友方颜色
   */
  friendly: "#3b82f6",

  /**
   * 中立颜色
   */
  neutral: "#a1a1aa",

  /**
   * 敌方颜色
   */
  hostile: "#ef4444",
} as const;

/**
 * 辅助文字样式
 */
export const TARGET_CARD_TEXT = {
  /**
   * 一键处置说明文字
   * 字号：9px | 颜色：弱化文字色
   */
  buttonHint: "mt-1 text-[9px] text-nexus-text-muted",

  /**
   * 空状态文字
   * 字号：11px | 颜色：弱化文字色
   */
  empty: "text-[11px] text-nexus-text-muted",

  /**
   * 次要标签文字
   * 字号：10px
   */
  secondaryLabel: "text-[10px] text-nexus-text-secondary",
} as const;
