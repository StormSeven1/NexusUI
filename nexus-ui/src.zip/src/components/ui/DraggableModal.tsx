"use client";

import { useState, useEffect, useRef, useCallback, ReactNode } from "react";
import { cn } from "@/lib/utils";
import { X } from "lucide-react";
import { ElementType } from "react";

export interface DraggableModalProps {
  /** 是否显示弹窗 */
  open: boolean;
  /** 关闭回调 */
  onClose: () => void;
  /** 弹窗标题 */
  title: string;
  /** 标题图标 (Lucide 组件) */
  icon?: ElementType;
  /** 弹窗尺寸: 'small' | 'medium' | 'large' | 'auto' (auto表示可调整大小) */
  size?: "small" | "medium" | "large" | "auto";
  /** 子内容 */
  children: ReactNode;
  /** 底部按钮区域 (可选) */
  footer?: ReactNode;
  /** 自定义类名 */
  className?: string;
  /** 初始位置 x (可选) */
  initialX?: number;
  /** 初始位置 y (可选) */
  initialY?: number;
  /** 最大高度 (可选) */
  maxHeight?: number;
  /** 标题栏右侧自定义按钮 (可选) */
  headerActions?: ReactNode;
  /** 最小宽度 (仅auto模式) */
  minWidth?: number;
  /** 最小高度 (仅auto模式) */
  minHeight?: number;
}

type ResizeDirection = 'n' | 's' | 'e' | 'w' | 'ne' | 'nw' | 'se' | 'sw';

/**
 * 统一弹窗设计规范
 *
 * 【窗体模式】
 * - 固定大小模式（size="small" | "medium" | "large"）：适用于设置对话框，宽度固定
 * - 可调整大小模式（size="auto"）：适用于数据展示对话框，用户可拖拽边缘/角落调整大小
 *
 * 【间距系统 - 左右紧凑、上下舒适】
 * - 标题栏内边距：px-2.5 py-3 (左右 10px、上下 12px)
 * - 内容区内边距：px-2.5 py-3.5 (左右 10px、上下 14px)
 * - 底部内边距：px-2.5 py-3 (左右 10px、上下 12px)
 * - 内容项间距：space-y-2.5 (10px) - 紧凑的垂直间距
 * - 内容项内间距：space-y-1.5 (6px) - 组内更紧凑
 *
 * 【尺寸规范 - 优化宽度】
 * - small: 320px - 适合简单设置、少量表单（固定大小）
 * - medium: 380px - 适合中等复杂度设置（固定大小，推荐）
 * - large: 460px - 适合复杂设置、双列布局（固定大小）
 * - auto: 可调整大小，初始 600x500，最小 300x200（可调整大小）
 *
 * 【图标和字号】
 * - 标题图标：16px - 适中大小
 * - 关闭按钮图标：16px - 易于点击
 * - 标题字号：text-sm (14px) font-semibold
 * - 正文默认字号：text-xs (12px)
 * - 小字说明：text-[10px]
 *
 * 【颜色规范】
 * - 背景：#212126（自定义深色背景）
 * - 边框：border-nexus-border
 * - 标题文字：text-nexus-text-primary
 * - 图标颜色：text-nexus-accent
 * - 关闭按钮：text-nexus-text-muted hover:text-nexus-text-primary
 * - 悬停背景：hover:bg-nexus-bg-hover
 */
const SIZE_CONFIG = {
  small: {
    width: 320,
    maxHeight: 500,
  },
  medium: {
    width: 380,
    maxHeight: 600,
  },
  large: {
    width: 460,
    maxHeight: 700,
  },
  auto: {
    width: 600, // 可调整大小的默认初始宽度
    height: 500, // 可调整大小的默认初始高度
  },
};

// 统一的样式配置 - 合理边距、紧凑布局
const UNIFIED_STYLES = {
  // 内边距 - 窗体边距舒适、内容布局紧凑
  titlePadding: "px-4 py-3",    // 左右 16px、上下 12px
  contentPadding: "px-4 py-3.5", // 左右 16px、上下 14px
  footerPadding: "px-4 py-3",    // 左右 16px、上下 12px

  // 图标大小 - 所有尺寸统一
  iconSize: 16,
  closeSize: 16,
} as const;

export function DraggableModal({
  open,
  onClose,
  title,
  icon: Icon,
  size = "small",
  children,
  footer,
  className,
  initialX,
  initialY,
  maxHeight,
  headerActions,
  minWidth = 300,
  minHeight = 200,
}: DraggableModalProps) {
  const config = SIZE_CONFIG[size];
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });

  // 可调整大小的状态
  const [isResizing, setIsResizing] = useState(false);

  const [modalSize, setModalSize] = useState(() => {
    if (size === "auto") {
      const autoConfig = config as { width: number; height: number };
      return { width: autoConfig.width, height: autoConfig.height };
    } else {
      const nonAutoConfig = config as { width: number; maxHeight: number };
      return { width: nonAutoConfig.width, height: maxHeight ?? nonAutoConfig.maxHeight };
    }
  });

  const dialogRef = useRef<HTMLDivElement>(null);

  // 使用 ref 存储 resize 时的即时值（避免状态更新延迟）
  const resizeStartPosRef = useRef({ x: 0, y: 0 });
  const resizeStartSizeRef = useRef({ width: 0, height: 0 });
  const resizeStartPositionRef = useRef({ x: 0, y: 0 }); // 窗体初始位置
  const [resizeDirection, setResizeDirection] = useState<ResizeDirection | null>(null);

  // 初始化位置
  useEffect(() => {
    if (open && position.x === 0 && position.y === 0) {
      const defaultX = initialX ?? window.innerWidth - modalSize.width - 20;
      const defaultY = initialY ?? 100;
      setPosition({ x: defaultX, y: defaultY });
    }
  }, [open, modalSize.width, initialX, initialY]);

  // 拖拽处理
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    // 只在标题栏区域触发拖拽
    if ((e.target as HTMLElement).closest(".drag-handle")) {
      setIsDragging(true);
      setDragOffset({
        x: e.clientX - position.x,
        y: e.clientY - position.y,
      });
    }
  }, [position]);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (isDragging) {
      const newX = e.clientX - dragOffset.x;
      const newY = e.clientY - dragOffset.y;

      // 限制弹窗不完全拖出视口
      const maxX = window.innerWidth - 50;
      const maxY = window.innerHeight - 50;

      setPosition({
        x: Math.max(-modalSize.width + 50, Math.min(newX, maxX)),
        y: Math.max(0, Math.min(newY, maxY)),
      });
    } else if (isResizing && resizeDirection) {
      // 调整大小逻辑 - 支持8个方向
      const deltaX = e.clientX - resizeStartPosRef.current.x;
      const deltaY = e.clientY - resizeStartPosRef.current.y;

      let newWidth = resizeStartSizeRef.current.width;
      let newHeight = resizeStartSizeRef.current.height;
      let newX = resizeStartPositionRef.current.x;
      let newY = resizeStartPositionRef.current.y;

      // 根据方向调整大小和位置
      if (resizeDirection.includes('e')) {
        newWidth = Math.max(minWidth, resizeStartSizeRef.current.width + deltaX);
      }
      if (resizeDirection.includes('w')) {
        newWidth = Math.max(minWidth, resizeStartSizeRef.current.width - deltaX);
        newX = resizeStartPositionRef.current.x + (resizeStartSizeRef.current.width - newWidth);
      }
      if (resizeDirection.includes('s')) {
        newHeight = Math.max(minHeight, resizeStartSizeRef.current.height + deltaY);
      }
      if (resizeDirection.includes('n')) {
        newHeight = Math.max(minHeight, resizeStartSizeRef.current.height - deltaY);
        newY = resizeStartPositionRef.current.y + (resizeStartSizeRef.current.height - newHeight);
      }

      setModalSize({ width: newWidth, height: newHeight });
      setPosition({ x: newX, y: newY });
    }
  }, [isDragging, isResizing, resizeDirection, dragOffset, modalSize.width, minWidth, minHeight]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
    setIsResizing(false);
    setResizeDirection(null);
  }, []);

  // 开始调整大小
  const handleResizeStart = useCallback((direction: ResizeDirection) => (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    setIsResizing(true);
    setResizeDirection(direction);
    // 使用 ref 存储即时值，避免状态更新延迟
    resizeStartPosRef.current = { x: e.clientX, y: e.clientY };
    resizeStartSizeRef.current = { width: modalSize.width, height: modalSize.height };
    resizeStartPositionRef.current = { x: position.x, y: position.y };
  }, [modalSize.width, modalSize.height, position.x, position.y]);

  useEffect(() => {
    if (isDragging || isResizing) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
      return () => {
        document.removeEventListener("mousemove", handleMouseMove);
        document.removeEventListener("mouseup", handleMouseUp);
      };
    }
  }, [isDragging, isResizing, handleMouseMove, handleMouseUp]);

  // ESC 键关闭
  useEffect(() => {
    if (!open) return;

    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      }
    };

    document.addEventListener("keydown", handleEscape);
    return () => document.removeEventListener("keydown", handleEscape);
  }, [open, onClose]);

  if (!open) return null;

  const isResizable = size === "auto";
  const effectiveMaxHeight = maxHeight ?? (size === "auto" ? modalSize.height : (config as { width: number; maxHeight: number }).maxHeight);

  return (
    <div
      ref={dialogRef}
      className={cn(
        "fixed z-50 rounded-lg border border-nexus-border shadow-xl",
        "transition-opacity duration-200",
        isDragging && "cursor-grabbing",
        isResizable && "resize-handle-active",
        className
      )}
      style={{
        left: `${position.x}px`,
        top: `${position.y}px`,
        width: `${modalSize.width}px`,
        height: size === "auto" ? `${modalSize.height}px` : 'auto',
        cursor: isDragging ? "grabbing" : isResizing ? "nwse-resize" : "auto",
        backgroundColor: "#212126",
      }}
      onMouseDown={handleMouseDown}
    >
      {/* 标题栏 - 可拖拽区域 */}
      <div
        className={cn(
          "drag-handle flex items-center justify-between border-b border-nexus-border cursor-grab active:cursor-grabbing",
          UNIFIED_STYLES.titlePadding
        )}
      >
        <div className="flex items-center gap-2">
          {Icon && <Icon size={UNIFIED_STYLES.iconSize} className="text-nexus-accent shrink-0" />}
          <h3 className="text-sm font-semibold text-nexus-text-primary">{title}</h3>
        </div>
        <div className="flex items-center gap-1">
          {headerActions}
          <button
            onClick={onClose}
            className="rounded p-1 text-nexus-text-muted hover:bg-nexus-bg-hover hover:text-nexus-text-primary transition-colors"
            aria-label="关闭"
          >
            <X size={UNIFIED_STYLES.closeSize} />
          </button>
        </div>
      </div>

      {/* 内容区域 */}
      <div
        className={cn("overflow-y-auto", UNIFIED_STYLES.contentPadding)}
        style={{ maxHeight: effectiveMaxHeight }}
      >
        {children}
      </div>

      {/* 底部按钮区域 */}
      {footer && (
        <div
          className={cn(
            "flex items-center justify-between border-t border-nexus-border",
            UNIFIED_STYLES.footerPadding
          )}
        >
          {footer}
        </div>
      )}

      {/* 调整大小手柄 - 仅在auto模式下显示 */}
      {isResizable && (
        <>
          {/* 北边 (上) */}
          <div
            className="absolute top-0 left-0 right-0 h-1 cursor-n-resize hover:bg-nexus-accent/20 transition-colors"
            onMouseDown={(e) => handleResizeStart('n')(e)}
          />
          {/* 南边 (下) */}
          <div
            className="absolute bottom-0 left-0 right-0 h-1 cursor-s-resize hover:bg-nexus-accent/20 transition-colors"
            onMouseDown={(e) => handleResizeStart('s')(e)}
          />
          {/* 东边 (右) */}
          <div
            className="absolute top-0 right-0 bottom-0 w-1 cursor-e-resize hover:bg-nexus-accent/20 transition-colors"
            onMouseDown={(e) => handleResizeStart('e')(e)}
          />
          {/* 西边 (左) */}
          <div
            className="absolute top-0 left-0 bottom-0 w-1 cursor-w-resize hover:bg-nexus-accent/20 transition-colors"
            onMouseDown={(e) => handleResizeStart('w')(e)}
          />
          {/* 东北角 (右上) */}
          <div
            className="absolute top-0 right-0 w-3 h-3 cursor-ne-resize hover:bg-nexus-accent/30 transition-colors"
            onMouseDown={(e) => handleResizeStart('ne')(e)}
          />
          {/* 西北角 (左上) */}
          <div
            className="absolute top-0 left-0 w-3 h-3 cursor-nw-resize hover:bg-nexus-accent/30 transition-colors"
            onMouseDown={(e) => handleResizeStart('nw')(e)}
          />
          {/* 东南角 (右下) */}
          <div
            className="absolute bottom-0 right-0 w-3 h-3 cursor-se-resize hover:bg-nexus-accent/30 transition-colors"
            onMouseDown={(e) => handleResizeStart('se')(e)}
          />
          {/* 西南角 (左下) */}
          <div
            className="absolute bottom-0 left-0 w-3 h-3 cursor-sw-resize hover:bg-nexus-accent/30 transition-colors"
            onMouseDown={(e) => handleResizeStart('sw')(e)}
          />
        </>
      )}
    </div>
  );
}
