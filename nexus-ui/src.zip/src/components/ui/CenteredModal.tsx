"use client";

import { useEffect, ReactNode } from "react";
import { cn } from "@/lib/utils";
import { X } from "lucide-react";
import { ElementType } from "react";

export interface CenteredModalProps {
  /** 是否显示弹窗 */
  open: boolean;
  /** 关闭回调 */
  onClose: () => void;
  /** 弹窗标题 */
  title?: string;
  /** 标题图标 (Lucide 组件) */
  icon?: ElementType;
  /** 弹窗尺寸: 'small' | 'medium' | 'large' */
  size?: "small" | "medium" | "large";
  /** 子内容 */
  children: ReactNode;
  /** 自定义类名 */
  className?: string;
  /** 最大高度 (可选) */
  maxHeight?: number;
  /** 是否显示背景遮罩 */
  showBackdrop?: boolean;
  /** 点击背景是否关闭 */
  closeOnBackdropClick?: boolean;
}

/**
 * 统一弹窗设计规范 (与 DraggableModal 保持一致)
 *
 * 【间距系统 - 紧凑优化版】
 * - 标题栏内边距：px-4 py-3 (16px 12px) - 居中弹窗略宽松以突出重要性
 * - 内容区内边距：px-4 py-4 (16px 16px) - 与标题栏协调
 * - 内容项间距：space-y-3 (12px) - 统一垂直间距
 * - 内容项内间距：space-y-2 (8px) - 组内垂直间距
 *
 * 【尺寸规范 - 优化宽度】
 * - small: max-w-[380px] - 适合简单确认
 * - medium: max-w-[520px] - 适合中等复杂度内容
 * - large: max-w-[680px] - 适合复杂内容、网格布局
 *
 * 【图标和字号】
 * - 标题图标：18px - 居中弹窗略大
 * - 关闭按钮图标：18px - 更易点击
 * - 标题字号：text-xl font-semibold (居中弹窗标题更大)
 *
 * 【颜色规范】
 * - 背景：#212126（统一背景色）
 * - 边框：border-white/[0.08]
 * - 标题文字：text-nexus-text-primary
 * - 图标颜色：text-nexus-accent
 * - 悬停背景：hover:bg-white/10
 */
const SIZE_CONFIG = {
  small: {
    width: "max-w-[380px]",
    maxHeight: 600,
  },
  medium: {
    width: "max-w-[520px]",
    maxHeight: 700,
  },
  large: {
    width: "max-w-[680px]",
    maxHeight: 800,
  },
};

// 统一的样式配置 (与 DraggableModal 保持一致)
const UNIFIED_STYLES = {
  // 内边距 - 所有尺寸统一
  titlePadding: "px-4 py-3",
  contentPadding: "px-4 py-4",

  // 图标大小 - 所有尺寸统一
  iconSize: 18,
  closeSize: 18,
} as const;

export function CenteredModal({
  open,
  onClose,
  title,
  icon: Icon,
  size = "medium",
  children,
  className,
  maxHeight,
  showBackdrop = true,
  closeOnBackdropClick = true,
}: CenteredModalProps) {
  const config = SIZE_CONFIG[size];

  // ESC 键关闭
  useEffect(() => {
    if (!open) return;

    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      }
    };

    document.addEventListener("keydown", handleEscape);
    return () => document.removeEventListener("keydown", handleEscape);
  }, [open, onClose]);

  // 禁止背景滚动
  useEffect(() => {
    if (open) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }

    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  if (!open) return null;

  const effectiveMaxHeight = maxHeight ?? config.maxHeight;
  const headerHeight = title ? 60 : 0; // 标题栏高度

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center">
      {/* 背景遮罩 */}
      {showBackdrop && (
        <div
          className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity duration-200"
          onClick={closeOnBackdropClick ? onClose : undefined}
        />
      )}

      {/* 弹窗容器 */}
      <div
        className={cn(
          "relative z-10 w-full overflow-hidden rounded-xl border border-white/[0.08] shadow-2xl transition-all duration-200",
          config.width,
          className
        )}
        style={{ maxHeight: effectiveMaxHeight, backgroundColor: "#212126" }}
      >
        {/* 标题栏 (可选) */}
        {title && (
          <div
            className={cn(
              "flex items-center justify-between border-b border-white/[0.06]",
              UNIFIED_STYLES.titlePadding
            )}
          >
            <div className="flex items-center gap-2">
              {Icon && <Icon size={UNIFIED_STYLES.iconSize} className="text-nexus-accent shrink-0" />}
              <h2 className="text-xl font-semibold text-nexus-text-primary">{title}</h2>
            </div>
            <button
              onClick={onClose}
              className="flex h-8 w-8 items-center justify-center rounded-md text-nexus-text-muted hover:bg-white/10 hover:text-nexus-text-primary transition-colors"
              aria-label="关闭"
            >
              <X size={UNIFIED_STYLES.closeSize} />
            </button>
          </div>
        )}

        {/* 内容区域 */}
        <div
          className={cn("overflow-y-auto", UNIFIED_STYLES.contentPadding)}
          style={{ maxHeight: effectiveMaxHeight - headerHeight }}
        >
          {children}
        </div>
      </div>
    </div>
  );
}
