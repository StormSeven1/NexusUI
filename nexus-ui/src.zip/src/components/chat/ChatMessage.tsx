"use client";

import Image from "next/image";
import { cn } from "@/lib/utils";
import {
  Bot, User, MapPin, Target, Map, PanelRight, Search,
  CheckCircle2, XCircle, Loader2, Sparkles, Navigation, Route, Ruler, Eraser,
  BarChart3, CloudSun, Pentagon, Waypoints, ShieldAlert, Plane, Radio,
  RotateCcw, ListTodo, RefreshCw, ClipboardList, Camera,
} from "lucide-react";
import { NxCard, NxBadge } from "@/components/nexus";
import { ChartCard } from "@/components/chat/ChartCard";
import { WeatherCard } from "@/components/chat/WeatherCard";
import { ThreatCard } from "@/components/chat/ThreatCard";
import { TaskCard } from "@/components/chat/TaskCard";
import { SurveillanceFeedCard } from "@/components/chat/SurveillanceFeedCard";
import type { SensorFeedData } from "@/components/chat/SurveillanceFeedCard";
import { AgentPlanCard } from "@/components/chat/AgentPlanCard";
import type { PlanStep } from "@/components/chat/AgentPlanCard";
import { ApprovalCard, ApprovalResultCard } from "@/components/chat/ApprovalCard";
import type { ApprovalCardProps } from "@/components/chat/ApprovalCard";
import type { UIMessage } from "ai";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

/* ──── 工具元数据 ──── */

const TOOL_META: Record<string, { icon: typeof MapPin; label: string; color: string }> = {
  navigate_to_location: { icon: MapPin, label: "地图导航", color: "text-sky-400" },
  select_track:         { icon: Target, label: "选中目标", color: "text-amber-400" },
  switch_map_mode:      { icon: Map, label: "切换视图", color: "text-emerald-400" },
  open_panel:           { icon: PanelRight, label: "打开面板", color: "text-purple-400" },
  query_tracks:         { icon: Search, label: "查询目标", color: "text-nexus-friendly" },
  highlight_tracks:     { icon: Sparkles, label: "高亮目标", color: "text-yellow-400" },
  fly_to_track:         { icon: Navigation, label: "飞向目标", color: "text-cyan-400" },
  draw_route:           { icon: Route, label: "绘制路线", color: "text-orange-400" },
  measure_distance:     { icon: Ruler, label: "测量距离", color: "text-teal-400" },
  clear_annotations:    { icon: Eraser, label: "清除标绘", color: "text-zinc-400" },
  query_data_chart:     { icon: BarChart3, label: "数据图表", color: "text-indigo-400" },
  get_weather:          { icon: CloudSun, label: "天气查询", color: "text-sky-300" },
  draw_area:            { icon: Pentagon, label: "区域标绘", color: "text-amber-500" },
  plan_route:           { icon: Waypoints, label: "航路规划", color: "text-cyan-300" },
  assess_threats:       { icon: ShieldAlert, label: "威胁评估", color: "text-red-400" },
  assign_asset:         { icon: Plane, label: "分配资产", color: "text-emerald-400" },
  recall_asset:         { icon: RotateCcw, label: "召回资产", color: "text-zinc-400" },
  command_asset:        { icon: Radio, label: "资产指令", color: "text-violet-400" },
  create_task:          { icon: ListTodo, label: "创建任务", color: "text-sky-400" },
  update_task:          { icon: RefreshCw, label: "更新任务", color: "text-sky-300" },
  get_task_status:      { icon: ClipboardList, label: "任务状态", color: "text-teal-400" },
  get_sensor_feed:      { icon: Camera, label: "传感器画面", color: "text-rose-400" },
};

interface ToolPartProps {
  type: string;
  toolName?: string;
  toolCallId?: string;
  state?: string;
  input?: unknown;
  output?: unknown;
  errorText?: string;
}

function resolveToolName(part: ToolPartProps): string {
  if (part.toolName) return part.toolName;
  if (part.type.startsWith("tool-")) return part.type.slice(5);
  return "unknown";
}

/* ──── Shimmer 思考动画（参照 Vercel chatbot） ──── */

function Shimmer({ text }: { text: string }) {
  return (
    <span className="inline-block animate-pulse text-[11px] font-medium text-nexus-text-secondary">
      {text}
    </span>
  );
}

/* ──── 工具调用卡片 ──── */

function ToolCallCard({ part }: { part: ToolPartProps }) {
  const toolName = resolveToolName(part);
  const meta = TOOL_META[toolName] ?? { icon: Bot, label: toolName, color: "text-nexus-text-muted" };
  const Icon = meta.icon;

  const isStreaming = part.state === "input-streaming";
  const isWaiting = part.state === "input-available";
  const isDone = part.state === "output-available";
  const isError = part.state === "output-error";

  const output = part.output as Record<string, unknown> | undefined;

  if (isDone && output?.action === "show_chart" && output.data) {
    return (
      <ChartCard
        chartType={(output.chartType as "bar" | "pie") ?? "bar"}
        data={output.data as Array<{ label: string; value: number; key?: string; group?: string }>}
        title={(output.title as string) ?? "数据图表"}
      />
    );
  }

  if (isDone && output?.action === "show_weather" && output.temperature != null) {
    return (
      <WeatherCard
        data={{
          location: output.location as string,
          temperature: output.temperature as number,
          condition: output.condition as string,
          icon: output.icon as string | undefined,
          humidity: output.humidity as number | undefined,
          wind: output.wind as string | undefined,
          visibilityKm: output.visibilityKm as number | undefined,
          pressureHpa: output.pressureHpa as number | undefined,
        }}
      />
    );
  }

  if (isDone && output?.action === "show_threats" && output.threats) {
    return (
      <ThreatCard
        threats={output.threats as Array<{
          trackId: string; name: string; typeLabel: string; dispositionLabel: string;
          score: number; level: string; levelLabel: string; reasons: string[];
          speed: number; nearestZone?: string; nearestZoneDist?: number | null;
        }>}
        totalAssessed={(output.total_assessed as number) ?? 0}
        summary={(output.summary as Record<string, number>) ?? {}}
      />
    );
  }

  if (isDone && output?.action === "show_task" && output.steps) {
    return (
      <TaskCard
        taskId={(output.taskId as string) ?? ""}
        title={(output.title as string) ?? "任务"}
        taskType={(output.taskType as string) ?? "recon"}
        status={(output.status as string) ?? "active"}
        steps={output.steps as Array<{ index: number; action: string; status: string; result?: string | null }>}
        progress={output.progress as string | undefined}
      />
    );
  }

  if (isDone && output?.action === "show_sensor_feed" && output.feedType) {
    return <SurveillanceFeedCard data={output as unknown as SensorFeedData} />;
  }

  if (output?.action === "show_plan" && output.steps) {
    return (
      <AgentPlanCard
        planId={(output.planId as string) ?? ""}
        steps={output.steps as PlanStep[]}
        currentStep={(output.currentStep as number) ?? 0}
      />
    );
  }

  if (toolName === "__approval__" && !isDone) {
    const input = part.input as Record<string, unknown> | undefined;
    if (input?.approval_id) {
      return (
        <ApprovalCard
          approvalId={input.approval_id as string}
          toolName={input.tool_name as string}
          toolCallId={input.tool_call_id as string}
          args={(input.args as Record<string, unknown>) ?? {}}
          description={(input.description as string) ?? "是否批准此操作？"}
        />
      );
    }
  }

  if (isDone && output?.action === "show_approval_result") {
    return (
      <ApprovalResultCard
        approvalId={(output.approval_id as string) ?? ""}
        approved={(output.approved as boolean) ?? false}
        reason={output.reason as string | undefined}
      />
    );
  }

  if (toolName === "__approval__" || toolName === "__plan__" || toolName === "declare_plan") {
    return null;
  }

  return (
    <NxCard padding="sm" className="my-1.5 transition-all duration-200">
      <div className="flex items-center gap-2">
        <div className={cn("flex h-5 w-5 items-center justify-center rounded", meta.color, "bg-current/10")}>
          <Icon size={11} className={meta.color} />
        </div>
        <span className="text-[10px] font-semibold tracking-wider text-nexus-text-secondary uppercase">
          {meta.label}
        </span>
        <span className="ml-auto">
          {(isStreaming || isWaiting) && <Loader2 size={11} className="animate-spin text-nexus-text-muted" />}
          {isDone && <CheckCircle2 size={11} className="text-emerald-400" />}
          {isError && <XCircle size={11} className="text-red-400" />}
        </span>
      </div>
      {isDone && typeof output?.message === "string" && (
        <p className="mt-1.5 text-[10px] leading-relaxed text-nexus-text-secondary">{output.message}</p>
      )}
      {isError && part.errorText && (
        <p className="mt-1.5 text-[10px] text-red-400">{part.errorText}</p>
      )}
    </NxCard>
  );
}

/* ──── 单条消息 ──── */

export function ChatMessage({ message, isStreaming }: { message: UIMessage; isStreaming?: boolean }) {
  const isUser = message.role === "user";
  const isAssistant = message.role === "assistant";

  const hasAnyContent = message.parts?.some(
    (part) =>
      (part.type === "text" && "text" in part && (part.text as string)?.trim().length > 0) ||
      (part.type === "reasoning" && "text" in part && (part.text as string)?.trim().length > 0) ||
      part.type.startsWith("tool-")
  );
  const isThinking = isAssistant && isStreaming && !hasAnyContent;

  // reasoning parts 不再合并，每步独立渲染

  return (
    <div className={cn("flex gap-2 px-3 py-2 animate-fade-in", isUser && "flex-row-reverse")}>
      {/* 头像 */}
      <div
        className={cn(
          "mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-md",
          isUser ? "bg-white/[0.08] text-nexus-text-primary" : "bg-sky-500/15 text-sky-400"
        )}
      >
        {isUser ? <User size={13} /> : <Bot size={13} />}
      </div>

      {/* 消息体 */}
      <div className={cn("min-w-0 flex-1 space-y-1", isUser && "text-right")}>
        <span className="text-[10px] font-medium text-nexus-text-muted">
          {isUser ? "操作员" : "Nexus AI"}
        </span>

        {isThinking ? (
          <div className="flex h-[18px] items-center">
            <Shimmer text="思考中..." />
          </div>
        ) : (
          message.parts.map((part, i) => {
            const key = `${message.id}-${i}`;

            if (part.type === "reasoning") {
              const rText = (part as { text: string }).text;
              if (!rText?.trim()) return null;
              const rStreaming = "state" in part && (part as { state: string }).state === "streaming";
              return (
                <details key={key} className="mt-1" open={rStreaming}>
                  <summary className="cursor-pointer text-[10px] text-nexus-text-muted hover:text-nexus-text-secondary transition-colors">
                    {rStreaming ? "▸ 思考中..." : "▸ 思考过程"}
                  </summary>
                  <p className="mt-1 rounded-md bg-white/[0.02] p-2 text-[10px] italic leading-relaxed text-nexus-text-muted whitespace-pre-wrap">
                    {rText}
                  </p>
                </details>
              );
            }

            // 文本
            if (part.type === "text" && part.text) {
              return (
                <div
                  key={key}
                  className={cn(
                    "nexus-markdown text-[11px] leading-relaxed text-nexus-text-primary",
                    isUser && "inline-block rounded-md bg-white/[0.06] px-2.5 py-1.5 text-left"
                  )}
                >
                  {isUser ? (
                    <span>{part.text}</span>
                  ) : (
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>{part.text}</ReactMarkdown>
                  )}
                </div>
              );
            }

            // 文件附件
            if (part.type === "file") {
              const isImage = part.mediaType?.startsWith("image/");
              if (isImage) {
                return (
                  <Image
                    key={key}
                    src={part.url}
                    alt={part.filename ?? "附件"}
                    width={320}
                    height={160}
                    unoptimized
                    className="mt-1 max-h-40 rounded-md border border-white/[0.06]"
                  />
                );
              }
              return (
                <NxBadge key={key} variant="info" className="mt-1">
                  {part.filename ?? "文件附件"}
                </NxBadge>
              );
            }

            // 工具调用
            if (part.type.startsWith("tool-") || part.type === "dynamic-tool") {
              return <ToolCallCard key={key} part={part as unknown as ToolPartProps} />;
            }

            return null;
          })
        )}
      </div>
    </div>
  );
}
