/**
 * ══════════════════════════════════════════════════════════════════════
 *  光电 FOV 渲染模块 —— FOV 扇区 + 名称标签 + 中心图标
 * ══════════════════════════════════════════════════════════════════════
 *
 * ── 光电/电侦渲染全链路 ──
 *
 *   1. 接收:
 *      ├─ 光电: WS entity_status → specificType="CAMERA"/"OPTOELECTRONIC"/"OPTICAL"/"光电" → asset_type="camera"
 *      │        或 camera/optoelectronic 独立消息 → 仅更新朝向/视场角/坐标
 *      └─ 电侦: WS entity_status → specificType="TOWER"/"ESM"/"电侦" → asset_type="tower"
 *
 *   2. 入资产:
 *      ├─ 静态: cameras.devices[] → mapCamerasDevicesPayload() → configAssetBase
 *      ├─ 动态: applyAssetListFromWs() → mergeDynamicAndStaticAssets() → asset-store
 *      └─ camera 独立消息 → 直接 patch asset-store 中已有光电的 heading/fov_angle/range_km
 *
 *   3. 渲染: asset-store → OptoelectronicFovModule.setFromAssets()
 *      ├─ buildFovGeoJSON() → 生成 FOV 扇区多边形 (geomKind="fov")
 *      │   ├─ 仅 camera 类型画 FOV 扇区；tower 由 tower-maplibre.ts 独立渲染
 *      │   ├─ 名称标签 (geomKind="lbl"): 有 name 且 nameLabelVisible≠false 就画，不依赖 range
 *      │   └─ 中心图标 (geomKind="ico"): 敌我配色 SVG 图标
 *      └─ 颜色: friendly → friendlyMapColor / label.textColor; hostile → FORCE_COLORS.hostile
 *
 *   4. 更新:
 *      ├─ entity_status 周期推送 → 整体替换 asset-store → 重新渲染
 *      └─ camera 消息 → parseCameraBearingDeg/parseCameraHorizontalFovDeg/parseCameraRangeKm
 *          与静态 cameras.devices 同 id 合并默认 bearing/angle/range
 *
 *   5. 超时: 无独立超时机制
 */
import type maplibregl from "maplibre-gl";
import { parseMapAssetTypeStrict, type Asset } from "@/lib/map-entity-model";
import type { AssetData } from "@/stores/asset-store";
import { parseForceDisposition } from "@/lib/theme-colors";
import { mergeRootAndDeviceVisible } from "@/lib/utils";
import type { AssetDispositionIconAccent, AssetStatus } from "@/lib/map-icons";
import {
  assetMapLabelTextColor,
  geoCircleCoords,
  geoSectorCoords,
  getAssetSymbolId,
  MAP_FRIENDLY_COLOR_PROP,
  MAP_LABEL_FONT_COLOR_PROP,
  MAPLIBRE_ASSET_CENTER_ICON_SIZE,
} from "@/lib/map-icons";
import type { AppConfigSectorBundle } from "@/lib/map-app-config";
import { laserLabelStyleFromBundle, laserSectorBorderFromBundle, resolveOptoFovStyle, sectorBundleAnyMergedVisible } from "@/lib/map-app-config";

/**
 * 光电（camera）FOV：GeoJSON 构建、`FOV_*` 常量、`OptoelectronicFovModule`。
 *
 * 【注意】本模块仅处理 camera（光电），不含 tower（电侦）。
 * 电侦的渲染完全独立，见 `tower-maplibre.ts`。
 * **`airports`** 解析与地图图层见 **`airport-maplibre.ts`**；**无人机**见 **`drones-maplibre.ts`**。
 */

function asRecord(v: unknown): Record<string, unknown> | null {
  return v && typeof v === "object" ? (v as Record<string, unknown>) : null;
}

/** 将 CSS 颜色转换为 rgba 字符串（与 radar-range-rings-maplibre.ts 中的实现一致） */
function cssColorToRgba(input: string, alpha: number): string | null {
  const s = input.trim();
  const a = Math.min(1, Math.max(0, alpha));
  if (!s) return null;
  if (s.startsWith("rgba(")) return s;
  if (s.startsWith("rgb(")) {
    const m = s.match(/rgb\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)/i);
    if (!m) return null;
    return `rgba(${m[1]},${m[2]},${m[3]},${a})`;
  }
  let hex = s.replace(/^#/, "");
  if (hex.length === 3) {
    hex = hex[0]! + hex[0]! + hex[1]! + hex[1]! + hex[2]! + hex[2]!;
  }
  if (hex.length !== 6) return null;
  const r = parseInt(hex.slice(0, 2), 16);
  const g = parseInt(hex.slice(2, 4), 16);
  const b = parseInt(hex.slice(4, 6), 16);
  if (![r, g, b].every((x) => Number.isFinite(x))) return null;
  return `rgba(${r},${g},${b},${a})`;
}

function rootVisibilityField(vis: Record<string, unknown> | null | undefined, key: string): boolean | undefined {
  if (!vis || !(key in vis)) return undefined;
  return vis[key] !== false;
}

function isoNow() {
  return new Date().toISOString();
}

/** `cameras.devices[]` / `airports.devices[]` 与 cameras 同形的一行 → `AssetData` */
function mapCameraDeviceRow(
  r: Record<string, unknown>,
  defaultRangeM: number,
  camerasVisibility: Record<string, unknown> | null | undefined,
  rootAssetFriendlyColor?: string | null,
  rootLabelFontColor?: string | null,
): AssetData | null {
  const id = String(r.deviceId ?? "");
  const c = r.center;
  if (!id || !Array.isArray(c) || c.length < 2) return null;
  const lng = Number(c[0]);
  const lat = Number(c[1]);
  if (!Number.isFinite(lng) || !Number.isFinite(lat)) return null;

  const rangeM = Number.isFinite(Number(r.range)) ? Number(r.range) : defaultRangeM;
  const assetType = parseMapAssetTypeStrict(r.assetType, `devices[${id}].assetType`);
  const bearing = Number(r.bearing);
  const heading = Number.isFinite(bearing) ? bearing : 0;
  const fovAngle = Number.isFinite(Number(r.fovAngle)) ? Number(r.fovAngle) : 90;
  const virtualTroop = r.virtualTroop === true;
  const now = isoNow();

  const centerNameVisible = mergeRootAndDeviceVisible(
    rootVisibilityField(camerasVisibility, "centerNameVisible"),
    r.centerNameVisible,
  );
  const centerIconVisible = mergeRootAndDeviceVisible(
    rootVisibilityField(camerasVisibility, "centerIconVisible"),
    r.centerIconVisible,
  );
  const fovSectorVisible = r.showSector !== false;

  const rowLbl = asRecord(r.label);
  const rowLabelColor = typeof rowLbl?.fontColor === "string" && rowLbl.fontColor.trim() ? rowLbl.fontColor.trim() : "";
  const rootLabelColor =
    typeof rootLabelFontColor === "string" && rootLabelFontColor.trim() ? rootLabelFontColor.trim() : "";
  const mapLabelColor = rowLabelColor || rootLabelColor;
  const rowAssetColor =
    typeof r.assetFriendlyColor === "string" && r.assetFriendlyColor.trim() ? r.assetFriendlyColor.trim() : "";
  const rootAssetColor =
    typeof rootAssetFriendlyColor === "string" && rootAssetFriendlyColor.trim() ? rootAssetFriendlyColor.trim() : "";
  const mapFriendly = rowAssetColor || rootAssetColor;

  return {
    id,
    name: String(r.name ?? id),
    asset_type: assetType,
    status: String(r.status ?? "online"),
    disposition: parseForceDisposition(r.disposition, "friendly"),
    lat,
    lng,
    range_km: rangeM > 0 ? rangeM / 1000 : null,
    heading,
    fov_angle: Number.isFinite(fovAngle) ? fovAngle : 90,
    properties: {
      ...(asRecord(r.properties as unknown) ?? {}),
      config_kind: "camera",
      is_virtual: virtualTroop,
      virtual_troop: virtualTroop,
      center_name_visible: centerNameVisible,
      center_icon_visible: centerIconVisible,
      fov_sector_visible: fovSectorVisible,
      ...(mapFriendly ? { [MAP_FRIENDLY_COLOR_PROP]: mapFriendly } : {}),
      ...(mapLabelColor ? { [MAP_LABEL_FONT_COLOR_PROP]: mapLabelColor } : {}),
    },
    mission_status: "monitoring",
    assigned_target_id: null,
    target_lat: null,
    target_lng: null,
    created_at: String(r.created_at ?? now),
    updated_at: now,
  };
}

/** 根键 `cameras` → 静态光电塔等 `AssetData[]` */
export function mapCamerasDevicesPayload(camerasRoot: unknown): AssetData[] {
  const root = asRecord(camerasRoot);
  if (!root || !Array.isArray(root.devices)) return [];
  const defM = Number(root.defaultRange) || 15_000;
  const vis = asRecord(root.visibility);
  const rootLbl = asRecord(root.label);
  const rootLabelFontColor =
    typeof rootLbl?.fontColor === "string" && rootLbl.fontColor.trim() ? rootLbl.fontColor.trim() : undefined;
  const rootAssetFriendlyColor =
    typeof root.assetFriendlyColor === "string" && root.assetFriendlyColor.trim() ? root.assetFriendlyColor.trim() : undefined;
  const out: AssetData[] = [];
  for (const item of root.devices) {
    if (!item || typeof item !== "object") continue;
    const a = mapCameraDeviceRow(item as Record<string, unknown>, defM, vis, rootAssetFriendlyColor, rootLabelFontColor);
    if (a) out.push(a);
  }
  return out;
}

export const FOV_SOURCE = "fov-source";
export const FOV_FILL = "fov-fill";
export const FOV_LABEL = "fov-label";

/** 光电(camera) 中心图标（电侦见 `tower-maplibre.ts`，机场见 `airport-maplibre.ts`） */
export const OPTO_ASSET_ICON_SOURCE = "opto-asset-icon-src";
export const OPTO_ASSET_ICON_LAYER = "opto-asset-icon";

export const FOV_LAYER_IDS = [FOV_FILL, FOV_LABEL] as const;

function assetStatusFromLabel(s: string | undefined): AssetStatus {
  const x = String(s ?? "online");
  if (x === "offline" || x === "degraded" || x === "online") return x;
  return "online";
}

/** 构建 FOV 多边形 + 名称点：仅处理 camera（光电），不含 tower（电侦） */
export function buildFovGeoJSON(
  assetList: Asset[],
  accent?: AssetDispositionIconAccent | null,
  cameraSettingsMap?: Record<string, CameraDisplaySettingsMap>
) {
  /* 仅光电(camera)画 FOV 扇区；电侦(tower)由 tower-maplibre 独立渲染 */
  const polyFeatures = assetList
    .filter((a) => {
      if (a.type !== "camera") return false;
      const settings = cameraSettingsMap?.[a.id];
      // 检查 showFov 设置（资产属性或设置面板）
      if (a.showFov === false) return false;
      if (settings?.showFovSector === false) return false;
      return a.range && a.range > 0;
    })
    .map((a) => {
      const settings = cameraSettingsMap?.[a.id];
      // 使用资产的原始距离和视场角
      const range = a.range;
      const fovAngle = a.fovAngle;
      const heading = a.heading;

      let coords: number[][];
      if (fovAngle !== undefined && heading !== undefined && fovAngle < 360 && range !== undefined) {
        const fov: number = fovAngle;
        const head: number = heading;
        const r: number = range;
        coords = geoSectorCoords(a.lng, a.lat, r, head, fov);
      } else if (range !== undefined) {
        coords = geoCircleCoords(a.lng, a.lat, range);
      } else {
        coords = [];
      }

      // 计算最终的填充颜色和透明度（与雷达实现一致）
      // 默认颜色
      const defaultFillColor = "rgba(147,51,234,0.10)";
      const defaultFillOpacity = 0.10;

      // 应用用户设置的颜色和透明度
      let effectiveFillColor = defaultFillColor;
      let effectiveFillOpacity = defaultFillOpacity;

      if (settings) {
        // 如果用户设置了填充颜色和透明度，合并成最终的 rgba 值
        if (settings.fovFillColor !== undefined) {
          const opacity = settings.fovFillOpacity !== undefined ? settings.fovFillOpacity : 0.2;
          const rgba = cssColorToRgba(settings.fovFillColor, opacity);
          if (rgba) {
            effectiveFillColor = rgba;
            effectiveFillOpacity = opacity;
          }
        } else if (settings.fovFillOpacity !== undefined) {
          effectiveFillOpacity = Math.min(1, Math.max(0, settings.fovFillOpacity));
        }
      }

      return {
        type: "Feature" as const,
        geometry: { type: "Polygon" as const, coordinates: [coords] },
        properties: {
          geomKind: "poly",
          id: a.id,
          name: a.name,
          status: a.status,
          assetType: a.type,
          isVirtual: a.isVirtual === true ? 1 : 0,
          // 只使用填充颜色，不使用边框
          fillColor: effectiveFillColor,
        },
      };
    });

  const labelFeatures: GeoJSON.Feature<GeoJSON.Point>[] = [];
  for (const a of assetList) {
    /* 仅光电(camera)画 FOV 名称标签；电侦(tower)由 tower-maplibre 独立渲染 */
    if (a.type !== "camera") continue;
    const settings = cameraSettingsMap?.[a.id];
    // 检查 showCenterLabel 设置（资产属性或设置面板）
    const showName = a.nameLabelVisible !== false &&
                     settings?.showCenterLabel !== false &&
                     String(a.name ?? "").trim() !== "";
    if (!showName) continue;
    const disp = a.disposition ?? "friendly";
    const st = assetStatusFromLabel(a.status);
    const friendlyOv = disp === "friendly" ? a.labelFontColor : undefined;
    const labelColor = assetMapLabelTextColor(disp, st, accent ?? null, friendlyOv);
    labelFeatures.push({
      type: "Feature",
      geometry: { type: "Point", coordinates: [a.lng, a.lat] },
      properties: {
        geomKind: "lbl",
        id: a.id,
        assetType: a.type,
        labelText: a.name,
        labelColor,
      },
    });
  }

  return {
    type: "FeatureCollection" as const,
    features: [...polyFeatures, ...labelFeatures] as GeoJSON.Feature[],
  };
}

/** 光电(camera) 中心图标（电侦/tower 已移至 `tower-maplibre.ts`，不再在此处理） */
export function buildOptoAssetIconGeoJSON(assetList: Asset[]): GeoJSON.FeatureCollection {
  return {
    type: "FeatureCollection",
    features: assetList
      .filter(
        (a) =>
          a.type === "camera" &&
          a.centerIconVisible !== false,
      )
      .map((a) => ({
        type: "Feature" as const,
        geometry: { type: "Point" as const, coordinates: [a.lng, a.lat] as [number, number] },
        properties: {
          id: a.id,
          assetType: a.type,
          symbolId: getAssetSymbolId(
            a.type,
            a.status,
            a.isVirtual ?? false,
            a.disposition ?? "friendly",
            (a.disposition ?? "friendly") === "friendly" ? a.friendlyMapColor : undefined,
          ),
          symbolOpacity: 1,
        },
      })),
  };
}

export type OptoelectronicFovVisibility = {
  fovFillVisible: boolean;
  fovLabelVisible: boolean;
  /** 光电/塔台中心图标（`opto-asset-icon`）；须与名称标签分开，勿复用 `fovLabelVisible` */
  fovIconVisible: boolean;
};

const fovVisDefault: OptoelectronicFovVisibility = {
  fovFillVisible: true,
  fovLabelVisible: true,
  fovIconVisible: true,
};

/**
 * 光电 FOV 扇区 + 光电中心图标：MapLibre 生命周期（与 `buildFovGeoJSON` 等同文件）。
 */
/**
 * 光电显示设置接口（对齐 camera-display-settings-store）
 */
export interface CameraDisplaySettingsMap {
  showFovSector?: boolean;
  showCenterLabel?: boolean;
  fovFillColor?: string;
  fovFillOpacity?: number;
}

export class OptoelectronicFovModule {
  private map: maplibregl.Map;
  private beforeId?: string;
  private coverageVis: OptoelectronicFovVisibility = { ...fovVisDefault };
  private assetDispositionAccent: AssetDispositionIconAccent | null = null;
  private lastFovAssets: Asset[] | null = null;
  private lastFovDataSig = "";
  private lastIconDataSig = "";
  private cameraSettingsMap: Record<string, CameraDisplaySettingsMap> = {};

  constructor(map: maplibregl.Map, options?: { insertBeforeLayerId?: string }) {
    this.map = map;
    this.beforeId = options?.insertBeforeLayerId;
  }

  install() {
    const m = this.map;
    const b = this.beforeId;

    if (!m.getSource(FOV_SOURCE)) {
      m.addSource(FOV_SOURCE, { type: "geojson", data: { type: "FeatureCollection", features: [] } });
    }
    if (!m.getLayer(FOV_FILL)) {
      m.addLayer(
        {
          id: FOV_FILL,
          type: "fill",
          source: FOV_SOURCE,
          filter: ["==", ["get", "geomKind"], "poly"],
          paint: {
            /* 光电 FOV 填充色（仅 camera）- 直接从 properties 读取最终计算的颜色值 */
            "fill-color": ["get", "fillColor"],
            "fill-opacity": 1, // 透明度已经在 fillColor 的 rgba 值中
          },
        },
        b,
      );
    }
    if (!m.getLayer(FOV_LABEL)) {
      m.addLayer(
        {
          id: FOV_LABEL,
          type: "symbol",
          source: FOV_SOURCE,
          filter: ["==", ["get", "geomKind"], "lbl"],
          layout: {
            "text-field": ["get", "labelText"],
            "text-font": ["Open Sans Semibold", "Arial Unicode MS Bold"],
            "text-size": 13,
            "text-anchor": "top",
            "text-offset": [0, 1.25],
            "text-allow-overlap": true,
            "text-ignore-placement": true,
            "text-max-width": 12,
          },
          paint: {
            "text-color": ["coalesce", ["get", "labelColor"], "#e5e5e5"],
            "text-halo-color": "rgba(0, 0, 0, 0.4)",
            "text-halo-width": 0.3,
            "text-halo-blur": 1.2,
            "text-opacity": 0.95,
          },
        },
        b,
      );
    }

    if (!m.getSource(OPTO_ASSET_ICON_SOURCE)) {
      m.addSource(OPTO_ASSET_ICON_SOURCE, { type: "geojson", data: { type: "FeatureCollection", features: [] } });
    }
    const sensorIconLayout: maplibregl.SymbolLayerSpecification["layout"] = {
      "icon-image": ["get", "symbolId"],
      "icon-size": MAPLIBRE_ASSET_CENTER_ICON_SIZE,
      "icon-allow-overlap": true,
      "icon-ignore-placement": true,
      "icon-rotation-alignment": "viewport",
      "icon-pitch-alignment": "viewport",
    };
    const sensorIconPaint: maplibregl.SymbolLayerSpecification["paint"] = {
      "icon-opacity": ["coalesce", ["get", "symbolOpacity"], 1],
    };
    if (!m.getLayer(OPTO_ASSET_ICON_LAYER)) {
      m.addLayer(
        {
          id: OPTO_ASSET_ICON_LAYER,
          type: "symbol",
          source: OPTO_ASSET_ICON_SOURCE,
          layout: sensorIconLayout,
          paint: sensorIconPaint,
        },
        b,
      );
    }

    this.applyFovLabelStyleFromBundle(null);
    this.applyCoverageLayerVisibility();
  }

  setCoverageLayerVisibility(partial: Partial<OptoelectronicFovVisibility>) {
    this.coverageVis = { ...this.coverageVis, ...partial };
    this.applyCoverageLayerVisibility();
  }

  private applyFovLabelStyleFromBundle(bundle: AppConfigSectorBundle | null) {
    const m = this.map;
    const L = laserLabelStyleFromBundle(bundle);
    for (const lid of [FOV_LABEL]) {
      if (!m.getLayer(lid)) continue;
      try {
        m.setLayoutProperty(lid, "text-font", L.textFont as string[]);
        m.setLayoutProperty(lid, "text-size", L.fontSize);
        m.setLayoutProperty(lid, "text-offset", L.textOffset as [number, number]);
        // 使用配置中的阴影设置
        m.setPaintProperty(lid, "text-halo-color", L.haloColor);
        m.setPaintProperty(lid, "text-halo-width", L.haloWidth);
        m.setPaintProperty(lid, "text-halo-blur", L.haloBlur);
      } catch {
        /* ignore */
      }
    }
    this.refreshFovLabelGeoJson();
  }

  setAssetDispositionAccent(accent: AssetDispositionIconAccent | null) {
    this.assetDispositionAccent = accent;
    this.lastFovDataSig = "";
    this.lastIconDataSig = "";
    this.refreshFovLabelGeoJson();
    this.refreshOptoIcons();
  }

  private refreshFovLabelGeoJson() {
    const m = this.map;
    const f = m.getSource(FOV_SOURCE) as maplibregl.GeoJSONSource | undefined;
    if (!f || !this.lastFovAssets) return;
    f.setData(
      buildFovGeoJSON(this.lastFovAssets, this.assetDispositionAccent, this.cameraSettingsMap) as GeoJSON.FeatureCollection,
    );
  }

  private refreshOptoIcons() {
    const m = this.map;
    const assets = this.lastFovAssets;
    if (!assets) return;
    const nextSig = this.buildOptoIconDataSig(assets);
    if (nextSig === this.lastIconDataSig) return;
    const os = m.getSource(OPTO_ASSET_ICON_SOURCE) as maplibregl.GeoJSONSource | undefined;
    if (os) {
      os.setData(buildOptoAssetIconGeoJSON(assets) as GeoJSON.FeatureCollection);
      this.lastIconDataSig = nextSig;
    }
  }

  applyCamerasBundle(bundle: AppConfigSectorBundle | null) {
    const m = this.map;
    const vis = bundle?.visibility;
    this.applyFovLabelStyleFromBundle(bundle);
    this.setCoverageLayerVisibility({
      fovFillVisible: vis?.sectorFillVisible !== false,
      fovLabelVisible: sectorBundleAnyMergedVisible(bundle, "centerNameVisible"),
      fovIconVisible: sectorBundleAnyMergedVisible(bundle, "centerIconVisible"),
    });
  }

  private applyCoverageLayerVisibility() {
    const m = this.map;
    const setVis = (id: string, show: boolean) => {
      if (!m.getLayer(id)) return;
      m.setLayoutProperty(id, "visibility", show ? "visible" : "none");
    };
    setVis(FOV_FILL, this.coverageVis.fovFillVisible);
    setVis(FOV_LABEL, this.coverageVis.fovLabelVisible);
    setVis(OPTO_ASSET_ICON_LAYER, this.coverageVis.fovIconVisible);
  }

  setFromAssets(assets: Asset[]) {
    this.lastFovAssets = assets;
    const m = this.map;
    const f = m.getSource(FOV_SOURCE) as maplibregl.GeoJSONSource | undefined;
    const nextFovSig = this.buildFovDataSig(assets);
    if (f) {
      f.setData(
        buildFovGeoJSON(assets, this.assetDispositionAccent, this.cameraSettingsMap) as GeoJSON.FeatureCollection,
      );
    }
    this.lastFovDataSig = nextFovSig;
    this.refreshOptoIcons();
  }

  /**
   * camera FOV 的轻量指纹：无关键字段变化时跳过 `setData`，降低 symbol 重排导致的闪烁。
   */
  private buildFovDataSig(assets: Asset[]): string {
    const quantizeDeg = (v: number | undefined): string => {
      const n = Number(v ?? 0);
      if (!Number.isFinite(n)) return "0.0";
      /* 角度容差：小于 0.1° 的变化视为同一档，避免微抖动触发重绘 */
      const q = Math.round(n * 10) / 10;
      return q.toFixed(1);
    };
    const rows = assets
      .filter((a) => a.type === "camera")
      .map((a) => {
        const settings = this.cameraSettingsMap?.[a.id];
        const range = Number(a.range ?? 0);
        return [
          a.id,
          Number(a.lng).toFixed(6),
          Number(a.lat).toFixed(6),
          Number.isFinite(range) ? range.toFixed(3) : "0",
          quantizeDeg(a.heading),
          quantizeDeg(a.fovAngle ?? 360),
          a.showFov === false ? "0" : "1",
          settings?.showFovSector === false ? "0" : "1",
          a.nameLabelVisible === false ? "0" : "1",
          settings?.showCenterLabel === false ? "0" : "1",
          a.name ?? "",
          a.status ?? "",
          a.disposition ?? "",
          a.labelFontColor ?? "",
          // 最终计算的颜色（用于检测颜色设置的变化）
          settings?.fovFillColor ?? "",
          settings?.fovFillOpacity ?? "",
        ].join("|");
      })
      .sort();
    return rows.join(";");
  }

  /**
   * 光电中心图标指纹：仅图标相关字段变化时刷新 icon source。
   */
  private buildOptoIconDataSig(assets: Asset[]): string {
    const rows = assets
      .filter((a) => a.type === "camera")
      .map((a) =>
        [
          a.id,
          Number(a.lng).toFixed(6),
          Number(a.lat).toFixed(6),
          a.centerIconVisible === false ? "0" : "1",
          a.status ?? "",
          a.disposition ?? "",
          a.isVirtual === true ? "1" : "0",
          a.friendlyMapColor ?? "",
        ].join("|"),
      )
      .sort();
    return rows.join(";");
  }

  dispose() {
    const m = this.map;
    for (const id of [OPTO_ASSET_ICON_LAYER, FOV_LABEL, FOV_FILL]) {
      if (m.getLayer(id)) m.removeLayer(id);
    }
    if (m.getSource(OPTO_ASSET_ICON_SOURCE)) m.removeSource(OPTO_ASSET_ICON_SOURCE);
    if (m.getSource(FOV_SOURCE)) m.removeSource(FOV_SOURCE);
  }

  /** 设置 per-camera 的显示设置（来自 camera-display-settings-store） */
  setCameraDisplaySettings(cameraSettingsMap: Record<string, CameraDisplaySettingsMap>) {
    this.cameraSettingsMap = cameraSettingsMap;
    const m = this.map;
    const f = m.getSource(FOV_SOURCE) as maplibregl.GeoJSONSource | undefined;
    if (f && this.lastFovAssets) {
      f.setData(buildFovGeoJSON(this.lastFovAssets, this.assetDispositionAccent, this.cameraSettingsMap) as GeoJSON.FeatureCollection);
    }
  }
}
