"use client";

import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { useAssetStore } from "@/stores/asset-store";
import { useCameraDisplaySettingsStore, DEFAULT_CAMERA_SETTINGS } from "@/stores/camera-display-settings-store";
import {
  Camera,
  Eye,
  EyeOff,
  Target,
  RefreshCw,
  ChevronDown
} from "lucide-react";
import { DraggableModal } from "@/components/ui/DraggableModal";
import { MODAL_STYLES, MODAL_BUTTONS, MODAL_FOOTER } from "@/lib/modal-styles";

interface CameraDisplaySettingsDialogProps {
  open: boolean;
  onClose: () => void;
}

export function CameraDisplaySettingsDialog({ open, onClose }: CameraDisplaySettingsDialogProps) {
  const assets = useAssetStore((s) => s.assets);
  const [selectedCameraId, setSelectedCameraId] = useState<string>("");
  const [cameraDropdownOpen, setCameraDropdownOpen] = useState(false);

  // 使用光电显示设置 store - 分离订阅每个字段
  const showFovSector = useCameraDisplaySettingsStore((s) =>
    selectedCameraId ? (s.settings[selectedCameraId]?.showFovSector ?? DEFAULT_CAMERA_SETTINGS.showFovSector) : DEFAULT_CAMERA_SETTINGS.showFovSector
  );
  const showCenterLabel = useCameraDisplaySettingsStore((s) =>
    selectedCameraId ? (s.settings[selectedCameraId]?.showCenterLabel ?? DEFAULT_CAMERA_SETTINGS.showCenterLabel) : DEFAULT_CAMERA_SETTINGS.showCenterLabel
  );
  const fovFillOpacity = useCameraDisplaySettingsStore((s) =>
    selectedCameraId ? (s.settings[selectedCameraId]?.fovFillOpacity ?? DEFAULT_CAMERA_SETTINGS.fovFillOpacity) : DEFAULT_CAMERA_SETTINGS.fovFillOpacity
  );
  const fovFillColor = useCameraDisplaySettingsStore((s) =>
    selectedCameraId ? (s.settings[selectedCameraId]?.fovFillColor ?? DEFAULT_CAMERA_SETTINGS.fovFillColor) : DEFAULT_CAMERA_SETTINGS.fovFillColor
  );

  const settings = {
    showFovSector,
    showCenterLabel,
    fovFillOpacity,
    fovFillColor,
  };

  const setCameraSettings = useCameraDisplaySettingsStore((s) => s.setCameraSettings);
  const resetCameraSettings = useCameraDisplaySettingsStore((s) => s.resetCameraSettings);

  const cameraAssets = assets.filter((asset) => asset.asset_type === "camera");

  useEffect(() => {
    if (open && cameraAssets.length > 0 && !selectedCameraId) {
      setSelectedCameraId(cameraAssets[0].id);
    }
  }, [open, cameraAssets.length, selectedCameraId, cameraAssets]);

  const handleCameraSelect = (cameraId: string) => {
    setSelectedCameraId(cameraId);
    setCameraDropdownOpen(false);
  };

  const handleSave = () => {
    onClose();
  };

  const handleReset = () => {
    if (selectedCameraId) {
      resetCameraSettings(selectedCameraId);
    }
  };

  const updateSetting = <K extends keyof typeof DEFAULT_CAMERA_SETTINGS>(
    key: K,
    value: typeof DEFAULT_CAMERA_SETTINGS[K]
  ) => {
    if (selectedCameraId) {
      setCameraSettings(selectedCameraId, { [key]: value });
    }
  };

  const selectedCamera = cameraAssets.find((c) => c.id === selectedCameraId);

  const footer = (
    <>
      <button
        onClick={handleReset}
        disabled={!selectedCamera}
        className={cn(
          MODAL_BUTTONS.auxiliary,
          !selectedCamera && MODAL_BUTTONS.disabled
        )}
      >
        <RefreshCw size={12} />
        重置
      </button>
      <div className={MODAL_FOOTER.rightGroup}>
        <button
          onClick={onClose}
          className={MODAL_BUTTONS.secondary}
        >
          取消
        </button>
        <button
          onClick={handleSave}
          disabled={!selectedCamera}
          className={cn(
            MODAL_BUTTONS.primary,
            !selectedCamera && MODAL_BUTTONS.disabled
          )}
        >
          保存
        </button>
      </div>
    </>
  );

  return (
    <DraggableModal
      open={open}
      onClose={onClose}
      title="光电显示设置"
      icon={Camera}
      size="medium"
      footer={footer}
    >
      <div className={MODAL_STYLES.spacing.main}>
        {/* 光电选择下拉菜单 */}
        <div className={MODAL_STYLES.spacing.group}>
          <label className={MODAL_STYLES.text.label}>选择光电</label>
          <div className="relative">
            <button
              onClick={() => setCameraDropdownOpen(!cameraDropdownOpen)}
              className={MODAL_STYLES.inputs.selectTrigger}
            >
              <span className="flex items-center gap-2 truncate">
                <Camera size={14} className="text-nexus-accent shrink-0" />
                {selectedCamera ? selectedCamera.name : "请选择光电"}
              </span>
              <ChevronDown
                size={14}
                className={cn(
                  "transition-transform duration-200 shrink-0",
                  cameraDropdownOpen ? "rotate-180" : ""
                )}
              />
            </button>

            {cameraDropdownOpen && (
              <div className={MODAL_STYLES.inputs.dropdownMenu} style={{ backgroundColor: "#19191D" }}>
                {cameraAssets.map((camera) => (
                  <button
                    key={camera.id}
                    onClick={() => handleCameraSelect(camera.id)}
                    className={cn(
                      MODAL_STYLES.inputs.dropdownItem,
                      selectedCameraId === camera.id && MODAL_STYLES.inputs.dropdownItemSelected
                    )}
                  >
                    <Camera size={12} className="shrink-0" />
                    <span className="truncate">{camera.name}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {selectedCamera && (
          <>
            {/* 显示选项 */}
            <div className={MODAL_STYLES.spacing.group}>
              <h4 className={MODAL_STYLES.text.sectionTitle}>显示选项</h4>

              <label className={MODAL_STYLES.toggles.container}>
                <div className={MODAL_STYLES.toggles.leftContainer}>
                  <Target size={14} className={MODAL_STYLES.toggles.icon} />
                  <span className={MODAL_STYLES.text.option}>显示视场角扇区</span>
                </div>
                <button
                  onClick={() => updateSetting('showFovSector', !settings.showFovSector)}
                  className={cn(
                    MODAL_BUTTONS.iconButton,
                    settings.showFovSector ? MODAL_STYLES.toggles.buttonEnabled : MODAL_STYLES.toggles.buttonDisabled
                  )}
                >
                  {settings.showFovSector ? <Eye size={14} /> : <EyeOff size={14} />}
                </button>
              </label>

              <label className={MODAL_STYLES.toggles.container}>
                <div className={MODAL_STYLES.toggles.leftContainer}>
                  <span className={MODAL_STYLES.text.option}>显示中心标签</span>
                </div>
                <button
                  onClick={() => updateSetting('showCenterLabel', !settings.showCenterLabel)}
                  className={cn(
                    MODAL_BUTTONS.iconButton,
                    settings.showCenterLabel ? MODAL_STYLES.toggles.buttonEnabled : MODAL_STYLES.toggles.buttonDisabled
                  )}
                >
                  {settings.showCenterLabel ? <Eye size={14} /> : <EyeOff size={14} />}
                </button>
              </label>
            </div>

            {/* 参数设置 */}
            <div className={MODAL_STYLES.spacing.group}>
              <h4 className={MODAL_STYLES.text.sectionTitle}>参数设置</h4>

              {/* FOV填充设置：透明度 + 颜色 */}
              <div className="flex items-center gap-4">
                <div className="flex-1 space-y-1.5">
                  <label className={MODAL_STYLES.text.label}>FOV填充透明度</label>
                  <input
                    type="number"
                    value={settings.fovFillOpacity}
                    onChange={(e) => updateSetting('fovFillOpacity', Number(e.target.value))}
                    className={MODAL_STYLES.inputs.base}
                    min="0"
                    max="1"
                    step="0.05"
                  />
                </div>

                <div className="flex-1 space-y-1.5">
                  <label className={MODAL_STYLES.text.label}>FOV填充颜色</label>
                  <div className="flex items-center gap-2 pl-1">
                    <input
                      type="color"
                      value={settings.fovFillColor}
                      onChange={(e) => updateSetting('fovFillColor', e.target.value)}
                      className="h-7 w-10 rounded cursor-pointer border border-nexus-border bg-[#19191D]"
                    />
                    <span className="text-xs text-nexus-text-muted">{settings.fovFillColor}</span>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </DraggableModal>
  );
}
