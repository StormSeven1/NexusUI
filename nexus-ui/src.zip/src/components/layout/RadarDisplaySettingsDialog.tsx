"use client";

import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { useAssetStore } from "@/stores/asset-store";
import { useRadarDisplaySettingsStore, DEFAULT_SETTINGS } from "@/stores/radar-display-settings-store";
import {
  Radio,
  Eye,
  EyeOff,
  Target,
  CircleDot,
  RefreshCw,
  ChevronDown,
} from "lucide-react";
import { DraggableModal } from "@/components/ui/DraggableModal";
import { MODAL_STYLES, MODAL_BUTTONS, MODAL_FOOTER, MODAL_SPACING, MODAL_TEXT, MODAL_INPUTS, MODAL_TOGGLES } from "@/lib/modal-styles";

interface RadarDisplaySettingsDialogProps {
  open: boolean;
  onClose: () => void;
}

export function RadarDisplaySettingsDialog({ open, onClose }: RadarDisplaySettingsDialogProps) {
  const assets = useAssetStore((s) => s.assets);
  const [selectedRadarId, setSelectedRadarId] = useState<string>("");
  const [radarDropdownOpen, setRadarDropdownOpen] = useState(false);

  // 使用雷达显示设置 store - 分离订阅每个字段以避免不必要的重新渲染
  const showCoverage = useRadarDisplaySettingsStore((s) =>
    selectedRadarId ? (s.settings[selectedRadarId]?.showCoverage ?? DEFAULT_SETTINGS.showCoverage) : DEFAULT_SETTINGS.showCoverage
  );
  const showRangeRings = useRadarDisplaySettingsStore((s) =>
    selectedRadarId ? (s.settings[selectedRadarId]?.showRangeRings ?? DEFAULT_SETTINGS.showRangeRings) : DEFAULT_SETTINGS.showRangeRings
  );
  const showCenterLabel = useRadarDisplaySettingsStore((s) =>
    selectedRadarId ? (s.settings[selectedRadarId]?.showCenterLabel ?? DEFAULT_SETTINGS.showCenterLabel) : DEFAULT_SETTINGS.showCenterLabel
  );
  const rangeRingInterval = useRadarDisplaySettingsStore((s) =>
    selectedRadarId ? (s.settings[selectedRadarId]?.rangeRingInterval ?? DEFAULT_SETTINGS.rangeRingInterval) : DEFAULT_SETTINGS.rangeRingInterval
  );
  const coverageFillOpacity = useRadarDisplaySettingsStore((s) =>
    selectedRadarId ? (s.settings[selectedRadarId]?.coverageFillOpacity ?? DEFAULT_SETTINGS.coverageFillOpacity) : DEFAULT_SETTINGS.coverageFillOpacity
  );
  const rangeRingColor = useRadarDisplaySettingsStore((s) =>
    selectedRadarId ? (s.settings[selectedRadarId]?.rangeRingColor ?? DEFAULT_SETTINGS.rangeRingColor) : DEFAULT_SETTINGS.rangeRingColor
  );
  const coverageFillColor = useRadarDisplaySettingsStore((s) =>
    selectedRadarId ? (s.settings[selectedRadarId]?.coverageFillColor ?? DEFAULT_SETTINGS.coverageFillColor) : DEFAULT_SETTINGS.coverageFillColor
  );

  // 组合成 settings 对象供后续使用
  const settings = {
    showCoverage,
    showRangeRings,
    showCenterLabel,
    rangeRingInterval,
    coverageFillOpacity,
    rangeRingColor,
    coverageFillColor,
  };

  const setRadarSettings = useRadarDisplaySettingsStore((s) => s.setRadarSettings);
  const resetRadarSettings = useRadarDisplaySettingsStore((s) => s.resetRadarSettings);
  const loadFromLocalStorage = useRadarDisplaySettingsStore((s) => s.loadFromLocalStorage);

  // 获取雷达资产列表
  const radarAssets = assets.filter((asset) => asset.asset_type === "radar");

  // 当弹窗打开时，加载设置并选择第一个雷达
  useEffect(() => {
    if (open && radarAssets.length > 0 && !selectedRadarId) {
      const firstRadarId = radarAssets[0].id;
      setSelectedRadarId(firstRadarId);
    }
  }, [open, radarAssets.length, selectedRadarId, radarAssets]);

  // 单独的 localStorage 加载（只在客户端执行一次）
  useEffect(() => {
    if (typeof window !== 'undefined' && open) {
      loadFromLocalStorage();
    }
  }, [open, loadFromLocalStorage]);

  // 当弹窗关闭时，重置选择状态
  useEffect(() => {
    if (!open) {
      setSelectedRadarId("");
    }
  }, [open]);

  // 当选择雷达时，选择该雷达（不需要额外操作，store会自动管理）
  const handleRadarSelect = (radarId: string) => {
    setSelectedRadarId(radarId);
    setRadarDropdownOpen(false);
  };

  // 更新单个设置项
  const updateSetting = <K extends keyof typeof DEFAULT_SETTINGS>(
    key: K,
    value: typeof DEFAULT_SETTINGS[K]
  ) => {
    if (selectedRadarId) {
      setRadarSettings(selectedRadarId, { [key]: value });
    }
  };

  // 保存设置（实际上是自动保存到 store 的，这里只需要关闭）
  const handleSave = () => {
    onClose();
  };

  // 重置为默认设置
  const handleReset = () => {
    if (selectedRadarId) {
      resetRadarSettings(selectedRadarId);
    }
  };

  // 获取当前选中的雷达信息
  const selectedRadar = radarAssets.find((r) => r.id === selectedRadarId);

  // 构建底部按钮区域
  const footer = (
    <>
      <button
        onClick={handleReset}
        disabled={!selectedRadar}
        className={cn(
          MODAL_BUTTONS.auxiliary,
          !selectedRadar && MODAL_BUTTONS.disabled
        )}
      >
        <RefreshCw size={12} />
        重置
      </button>
      <div className={MODAL_FOOTER.rightGroup}>
        <button
          onClick={onClose}
          className={MODAL_BUTTONS.secondary}
        >
          取消
        </button>
        <button
          onClick={handleSave}
          disabled={!selectedRadar}
          className={cn(
            MODAL_BUTTONS.primary,
            !selectedRadar && MODAL_BUTTONS.disabled
          )}
        >
          保存
        </button>
      </div>
    </>
  );

  return (
    <DraggableModal
      open={open}
      onClose={onClose}
      title="雷达显示设置"
      icon={Radio}
      size="medium"
      footer={footer}
    >
      <div className={MODAL_SPACING.main}>
        {/* 雷达选择下拉菜单 */}
        <div className={MODAL_SPACING.group}>
          <label className={MODAL_TEXT.label}>选择雷达</label>
          <div className="relative">
            <button
              onClick={() => setRadarDropdownOpen(!radarDropdownOpen)}
              className={MODAL_INPUTS.selectTrigger}
            >
              <span className="flex items-center gap-2 truncate">
                <Radio size={14} className="text-nexus-accent shrink-0" />
                {selectedRadar ? selectedRadar.name : "请选择雷达"}
              </span>
              <ChevronDown
                size={14}
                className={cn(
                  "transition-transform duration-200 shrink-0",
                  radarDropdownOpen ? "rotate-180" : ""
                )}
              />
            </button>

            {/* 下拉菜单 */}
            {radarDropdownOpen && (
              <div className={MODAL_INPUTS.dropdownMenu} style={{ backgroundColor: "#19191D" }}>
                {radarAssets.map((radar) => (
                  <button
                    key={radar.id}
                    onClick={() => handleRadarSelect(radar.id)}
                    className={cn(
                      MODAL_INPUTS.dropdownItem,
                      selectedRadarId === radar.id && MODAL_INPUTS.dropdownItemSelected
                    )}
                  >
                    <Radio size={12} className="shrink-0" />
                    <span className="truncate">{radar.name}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* 只有选择雷达后才显示配置选项 */}
        {selectedRadar && (
          <>
            {/* 显示选项 */}
            <div className={MODAL_SPACING.group}>
              <h4 className={MODAL_TEXT.sectionTitle}>显示选项</h4>

              <label className={MODAL_TOGGLES.container}>
                <div className={MODAL_TOGGLES.leftContainer}>
                  <Target size={14} className={MODAL_TOGGLES.icon} />
                  <span className={MODAL_TEXT.option}>显示覆盖范围</span>
                </div>
                <button
                  onClick={() => updateSetting('showCoverage', !settings.showCoverage)}
                  className={cn(
                    MODAL_BUTTONS.iconButton,
                    settings.showCoverage ? MODAL_TOGGLES.buttonEnabled : MODAL_TOGGLES.buttonDisabled
                  )}
                >
                  {settings.showCoverage ? <Eye size={14} /> : <EyeOff size={14} />}
                </button>
              </label>

              <label className={MODAL_TOGGLES.container}>
                <div className={MODAL_TOGGLES.leftContainer}>
                  <CircleDot size={14} className={MODAL_TOGGLES.icon} />
                  <span className={MODAL_TEXT.option}>显示距离环</span>
                </div>
                <button
                  onClick={() => updateSetting('showRangeRings', !settings.showRangeRings)}
                  className={cn(
                    MODAL_BUTTONS.iconButton,
                    settings.showRangeRings ? MODAL_TOGGLES.buttonEnabled : MODAL_TOGGLES.buttonDisabled
                  )}
                >
                  {settings.showRangeRings ? <Eye size={14} /> : <EyeOff size={14} />}
                </button>
              </label>

              <label className={MODAL_TOGGLES.container}>
                <div className={MODAL_TOGGLES.leftContainer}>
                  <span className={MODAL_TEXT.option}>显示中心标签</span>
                </div>
                <button
                  onClick={() => updateSetting('showCenterLabel', !settings.showCenterLabel)}
                  className={cn(
                    MODAL_BUTTONS.iconButton,
                    settings.showCenterLabel ? MODAL_TOGGLES.buttonEnabled : MODAL_TOGGLES.buttonDisabled
                  )}
                >
                  {settings.showCenterLabel ? <Eye size={14} /> : <EyeOff size={14} />}
                </button>
              </label>
            </div>

            {/* 参数设置 */}
            <div className={MODAL_SPACING.group}>
              <h4 className={MODAL_TEXT.sectionTitle}>参数设置</h4>

              {/* 距离环设置：间隔 + 颜色 */}
              <div className="flex items-center gap-4">
                <div className="flex-1 space-y-1.5">
                  <label className={MODAL_TEXT.label}>距离环间隔 (公里)</label>
                  <input
                    type="number"
                    value={(settings.rangeRingInterval / 1000).toFixed(1)}
                    onChange={(e) => updateSetting('rangeRingInterval', Math.round(Number(e.target.value) * 1000))}
                    className={MODAL_INPUTS.base}
                    min="0.5"
                    max="10"
                    step="0.5"
                  />
                </div>

                <div className="flex-1 space-y-1.5">
                  <label className={MODAL_TEXT.label}>距离环颜色</label>
                  <div className="flex items-center gap-2 pl-1">
                    <input
                      type="color"
                      value={settings.rangeRingColor}
                      onChange={(e) => updateSetting('rangeRingColor', e.target.value)}
                      className="h-7 w-10 rounded cursor-pointer border border-nexus-border bg-[#19191D]"
                    />
                    <span className="text-xs text-nexus-text-muted">{settings.rangeRingColor}</span>
                  </div>
                </div>
              </div>

              {/* 覆盖区域设置：透明度 + 颜色 */}
              <div className="flex items-center gap-4">
                <div className="flex-1 space-y-1.5">
                  <label className={MODAL_TEXT.label}>覆盖填充透明度</label>
                  <input
                    type="number"
                    value={settings.coverageFillOpacity}
                    onChange={(e) => updateSetting('coverageFillOpacity', Number(e.target.value))}
                    className={MODAL_INPUTS.base}
                    min="0"
                    max="1"
                    step="0.05"
                  />
                </div>

                <div className="flex-1 space-y-1.5">
                  <label className={MODAL_TEXT.label}>覆盖填充颜色</label>
                  <div className="flex items-center gap-2 pl-1">
                    <input
                      type="color"
                      value={settings.coverageFillColor}
                      onChange={(e) => updateSetting('coverageFillColor', e.target.value)}
                      className="h-7 w-10 rounded cursor-pointer border border-nexus-border bg-[#19191D]"
                    />
                    <span className="text-xs text-nexus-text-muted">{settings.coverageFillColor}</span>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </DraggableModal>
  );
}
